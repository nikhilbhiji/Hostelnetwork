<?php
	$json["success"] = "record inserted";
	echo json_encode($json);
?>