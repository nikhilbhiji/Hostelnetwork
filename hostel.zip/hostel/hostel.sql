-- phpMyAdmin SQL Dump
-- version 3.4.10.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 02, 2016 at 01:24 PM
-- Server version: 5.5.20
-- PHP Version: 5.3.10

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `hostel`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `uname` varchar(50) NOT NULL,
  `upass` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `uname`, `upass`) VALUES
(1, 'admin', 'YWRtaW4=');

-- --------------------------------------------------------

--
-- Table structure for table `booking`
--

CREATE TABLE IF NOT EXISTS `booking` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `mobile_no` varchar(30) NOT NULL,
  `email` varchar(250) NOT NULL,
  `hostel_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `booking`
--

INSERT INTO `booking` (`id`, `name`, `mobile_no`, `email`, `hostel_id`) VALUES
(1, 'viksa', '8295333820', 'saini391@gmail.com', 1),
(2, 'vikas', '8296487855', 'saini391@gmail.com', 4),
(3, 'kamal', '8296487855', 'saini391@gmail.com', 4);

-- --------------------------------------------------------

--
-- Table structure for table `city`
--

CREATE TABLE IF NOT EXISTS `city` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `city_name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `city`
--

INSERT INTO `city` (`id`, `city_name`) VALUES
(1, 'zirakpur'),
(2, 'chandigarh');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE IF NOT EXISTS `feedback` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `email_id` varchar(250) NOT NULL,
  `feedback_category` varchar(250) NOT NULL,
  `message` text NOT NULL,
  `contact_no` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`id`, `name`, `email_id`, `feedback_category`, `message`, `contact_no`) VALUES
(1, 'vikas', 'saini391@gmail.com', 'Address Details are Wrong.', 'askldfla sdfklasd                                    \r\n                                ', 'sdl');

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE IF NOT EXISTS `reviews` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `review_title` varchar(100) NOT NULL,
  `review_description` text NOT NULL,
  `rating` int(10) NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `contact` varchar(15) NOT NULL,
  `hostel_id` int(30) NOT NULL,
  `created` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `reviews`
--

INSERT INTO `reviews` (`id`, `review_title`, `review_description`, `rating`, `user_name`, `email`, `contact`, `hostel_id`, `created`) VALUES
(1, 'asdjlk', 'aksldjf', 4, '', 'admin@gmail.com', '8295333824', 4, '2016-04-18'),
(2, 'About Feedback', 'Good Service', 2, '', 'kamal@gmail.com', '8295333824', 4, '2016-04-18');

-- --------------------------------------------------------

--
-- Table structure for table `signup`
--

CREATE TABLE IF NOT EXISTS `signup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `property_for` varchar(20) NOT NULL,
  `property_type` varchar(20) NOT NULL,
  `occupancy` varchar(10) NOT NULL,
  `property_name` varchar(100) NOT NULL,
  `owner_name` varchar(100) NOT NULL,
  `mobile_no` varchar(20) NOT NULL,
  `alternate_no` varchar(20) NOT NULL,
  `house_no` varchar(100) NOT NULL,
  `landmark` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `img` varchar(250) NOT NULL,
  `img2` varchar(255) NOT NULL,
  `img3` varchar(255) NOT NULL,
  `img4` varchar(255) NOT NULL,
  `img5` varchar(250) NOT NULL,
  `food_type` varchar(50) NOT NULL,
  `meals` varchar(50) NOT NULL,
  `room_rent` int(10) NOT NULL,
  `room_security` int(10) NOT NULL,
  `room_rent1` varchar(100) NOT NULL,
  `room_security1` varchar(100) NOT NULL,
  `facilities` text NOT NULL,
  `house_rule` text NOT NULL,
  `location` text NOT NULL,
  `lat` varchar(30) NOT NULL,
  `long` varchar(30) NOT NULL,
  `status` int(2) NOT NULL DEFAULT '0',
  `views` int(11) NOT NULL DEFAULT '0',
  `city` varchar(100) NOT NULL,
  `youtube_link` varchar(250) NOT NULL,
  `created` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `signup`
--

INSERT INTO `signup` (`id`, `property_for`, `property_type`, `occupancy`, `property_name`, `owner_name`, `mobile_no`, `alternate_no`, `house_no`, `landmark`, `email`, `password`, `img`, `img2`, `img3`, `img4`, `img5`, `food_type`, `meals`, `room_rent`, `room_security`, `room_rent1`, `room_security1`, `facilities`, `house_rule`, `location`, `lat`, `long`, `status`, `views`, `city`, `youtube_link`, `created`) VALUES
(1, 'male', 'pg', 'single', 'hari ho property', 'vikas saini', '8388934', '3847389798', 'ajsdlj', 'kjslkdj', 'saini391@gmail.com', 'dmlrYXMzOTE=', 'upload_2016-04-1816-00-339829.png', 'upload_2016-04-1816-00-167077.jpg', 'upload_2016-04-1816-00-179225.jpg', 'upload_2016-04-1816-00-179532.jpg', 'upload_2016-04-2903-23-595423.jpg', 'veg', 'breakfast#lunch', 100, 30, '', '', '24_water#cc_camera#laundry#kitchen#table_chair', 'non_veg#drinking#entry_9pm', 'ambala cantt, haryana, india', '30.3610314', '76.84854680000001', 0, 84, 'zirakpur', '', ''),
(2, 'female', 'hostel', 'sharing', 'om pro', 'jhjk', 'hkjh', 'jkh', 'jkjjkh', 'jkh', 'vikas@gmail.com', 'dmlrYXMzOTE=', 'upload_2016-04-0314-46-311937.gif', '', '', '', '', 'non_veg', 'breakfast#dinner', 673, 676, '76#67#8#878', '767#87#87#76', 'housekeeping#cc_camera#laundry#kitchen', 'guardian_entry#non_veg#boy_entry#entry_9pm', 'saha, ambala cantt, haryana, india', '30.3009077', '76.96484609999993', 0, 1, '', '', ''),
(3, 'female', 'pg', 'sharing', 'jkklj', 'lkjlk', 'jlkj', 'lkjjlkkl', 'jlkkl', 'jlkjl', 'vikas@gmail.com', 'dmlrYXM=', 'upload_2016-04-0804-07-263958.gif', '', '', '', '', 'veg#non_veg', 'breakfast#lunch#dinner', 30, 4, '49#49#0#0', '9#9#0#0', 'security#parking', 'guardian_entry#drinking#entry_9pm', 'jj', '30.3006126', '76.96718650000003', 0, 1, '', '', ''),
(4, 'male', 'hostel', 'single', 'lksdjfkj', 'sjdfl', 'ksjdfk', 'aksjd', 'kjsfj', 'ksjdfk', 'kamal@gmail.com', 'a2FtYWw=', 'upload_2016-04-1202-58-599774.jpg', '', '', '', '', 'veg#non_veg', 'breakfast#lunch', 30, 2, '', '', 'parking#24_water#ac#cc_camera#kitchen#table_chair', 'guardian_entry#drinking#entry_10pm', 'ambala,haryana,india,133104', '30.3781788', '76.77669739999999', 0, 44, '', '', ''),
(5, 'male', 'hostel', 'sharing', 'gjk', 'hkj', 'kjh', 'kjh', 'kjhkj', 'hkjh', 'par@gmail.com', 'cGFyQDEyMw==', 'upload_2016-04-2802-31-106954.jpg', '', '', '', '', 'veg', 'lunch#dinner#special', 7, 7, '7#7#7#7', '7#77#7#8', 'tv_room#wather_cooler#ac', 'guardian_entry#drinking#entry_9pm', 'kjh', '', '', 0, 2, 'ambala', '', '');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
