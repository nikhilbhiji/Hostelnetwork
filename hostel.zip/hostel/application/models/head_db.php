<?php
class Head_db extends CI_Model
{
    private $db;
    public function __construct()
    {
        parent::__construct();
        $this->db = $this->load->database("default", TRUE);
    }
    public function head_user($head)
    {
        $query = $this->db->get_where('admin', $head);
        return $query->row_array();
    }
    public function insert_city($city)
    {
        $this->db->insert("city",$city);
    }
    public function get_cities()
    {
        $query = $this->db->get("city");
        return $query->result_array();
    }
    public function delete_city($id)
    {
        $this->db->delete("city",array("id"=>$id));
    }
}
?>