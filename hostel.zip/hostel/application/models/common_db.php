<?php
class Common_db extends CI_Model
{
    private $db;
    public function __construct()
    {
        parent::__construct();
        $this->db = $this->load->database("default", TRUE);
    }
    public function insert_signup($signup)
    {
        $this->db->insert("signup",$signup);
    }
    public function get_recent_hostels()
    {
        $query = "select avg(reviews.rating) as 'total_rating', signup.* from signup left join reviews on signup.id = reviews.hostel_id group by signup.id order by signup.id desc limit 4";
        $res = $this->db->query($query);
        return $res->result_array();
    }
    public function search_hostels($price,$gender,$location,$property_type,$food_type,$occupancy)
    {
        $query = "select avg(reviews.rating) as 'total_rating', signup.* from signup left join reviews on signup.id = reviews.hostel_id where signup.room_rent<='".$price."' and signup.property_for='".$gender."' and signup.location like '%".$location."%' and signup.property_type like '%".$property_type."%' and signup.food_type like '%".$food_type."%' and occupancy like '%".$occupancy."%' group by signup.id ";
        $res = $this->db->query($query);
        return $res->result_array();
    }
    public function search_hostels1($location)
    {
        $query = "select id,property_name,property_type,property_type,property_for,img,location,occupancy,room_rent,room_rent1 from signup where location like '%".$location."%'";
        $res = $this->db->query($query);
        return $res->result_array();
    }
    public function get_single_hostel($id)
    {
        $query = $this->db->get_where("signup",array("id"=>$id));
        return $query->row_array();
    }
    public function login_user($u,$p)
    {
        $query = $this->db->get_where('signup', array('email' => $u,'password' => base64_encode($p)));
        return $query;
    }
    public function get_profile_detail($id)
    {
        $query = $this->db->get_where("signup",array("id"=>$id));
        return $query->row_array();
    }
    public function update_profile($profile,$user_id)
    {
        $this->db->where('id', $user_id);
        $this->db->update('signup', $profile);
    }
    public function insert_booking($booking)
    {
        $this->db->insert("booking",$booking);        
    }
    public function get_bookings($uid)
    {
        $query = $this->db->get_where("booking",array("hostel_id"=>$uid));
        return $query->result_array();
    }
    public function insert_review($review)
    {
        $this->db->insert("reviews",$review);
    }
    public function delete_booking($hid,$bid)
    {
        $this->db->delete('booking', array('id' => $bid,'hostel_id'=>$hid));
    }
    public function get_hostel_view($id)
    {
        $this->db->select("views");
        $query = $this->db->get_where("signup",array("id"=>$id));
        return $query->row_array();
    }
    public function update_views($new_views,$id)
    {
        $views["views"] = $new_views;
        $this->db->where('id', $id);
        $this->db->update('signup', $views);
    }
    public function insert_feedback($feedback)
    {
        $this->db->insert("feedback",$feedback);
    }
    public function get_cities()
    {
//        $query = $this->db->get("city");
        $query = $this->db->query("select * from city order by city_name asc");
        return $query->result_array();
    }
    public function get_hostel_bysearch($search)
    {
        $query = $this->db->query("select * from signup where location like '%".$search."%'");
        return $query->result_array();
    }
     public function check_email($email)
    {
        $query = $this->db->get_where("signup",array("email"=>$email));
        return $query->row_array();
    }
    public function get_reviews($id)
    {
        $query = $this->db->get_where("reviews",array("hostel_id"=>$id));
        return $query->result_array();
    }
}
?>