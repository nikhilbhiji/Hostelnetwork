<br clear="all"/>

<div class="container">
    <div class="row " >   
        <div class="col-md-12">
            <h3 class="mb15" align="center">Registration</h3>
            <script type="text/javascript">
                function check_vali()
                {
                    if(document.getElementById("map_address").value == "")
                    {
                        alert("please set your location map");
                        document.getElementById("map_address").focus();
                        return false;
                    }
                    return true;
                }
                </script>
            <form action="<?php echo base_url() ?>home/signup_action" method="post" enctype="multipart/form-data" onsubmit="return check_vali();">
                <div class="col-md-4">   
                    <h5>Property Information</h5>
                    <hr/>
                    <div class="form-group ">
                        <label>Property For</label>
                        <input type="radio" name="property_for" checked="" value="male" id="male" > <label for="male" style="display:inline;">Male </label>&nbsp;&nbsp;&nbsp;
                        <input type="radio" name="property_for" value="female" id="female"> <label for="female" style="display:inline">Female </label>
                    </div>
                    <div class="form-group ">
                        <label>Property Type</label>
                        <input type="radio" name="property_type" checked="" value="hostel" id="hostel_type" > <label for="hostel_type" style="display:inline;">Hostel </label>&nbsp;&nbsp;&nbsp;
                        <input type="radio" name="property_type" value="pg" id="pg_type"> <label for="pg_type" style="display:inline">P.G.</label>&nbsp;&nbsp;&nbsp;
                        <input type="radio" name="property_type" value="room" id="room_type"> <label for="room_type" style="display:inline">Room</label>
                    </div>
                    <script type="text/javascript">
                        function check_sharing()
                        {

                            if (document.getElementById("single").checked == true)
                            {
                                $(document).ready(function() {
                                    $(".rt_class").attr("disabled", true);                                    
                                    $("#room_security").attr("disabled", false);
                                    $("#room_rent").attr("disabled", false);
                                });
                            }
                            if (document.getElementById("single").checked == false)
                            {
                                $(document).ready(function() {
                                    $(".rt_class").attr("disabled", false);
                                    $("#room_security").attr("disabled", true);
                                    $("#room_rent").attr("disabled", true);
                                });
                            }
                        }
                    </script>
                    <div class="form-group ">
                        <label>Occupancy</label>
                        <input type="radio" name="occupancy" value="single" onclick="check_sharing()" id="single" > <label for="single" style="display:inline;">Single Room </label>&nbsp;&nbsp;&nbsp;
                        <input type="radio" name="occupancy" value="sharing" checked="true" onclick="check_sharing()" id="sharing"> <label for="sharing" style="display:inline">Sharing Rooms </label>
                    </div>
                    <div class="form-group ">                       
                        <input type="text" placeholder="Property Name"  name="property_name" class="form-control">
                    </div>
                    <div class="form-group ">                       
                        <input type="text" placeholder="Owner Name" required="" name="owner_name" class="form-control">
                    </div>
                    <div class="form-group ">                       
                        <input type="text" placeholder="Mobile No." required="" name="mobile_no" class="form-control">
                    </div>
                    <div class="form-group ">                       
                        <input type="text" placeholder="Phone/Alternate Mobile No." name="alternate_no" class="form-control">
                    </div>                 
                    <div class="form-group ">                       
                        <input type="text" placeholder="House No., Street" name="house_no" class="form-control">
                    </div>
                    <div class="form-group ">                       
                        <input type="text" placeholder="Landmark" name="landmark" class="form-control">
                    </div>
                    <div class="form-group">
                        <input id="main_address" class="form-control" placeholder="Area, City, State, Country and Pincode" name="location" type="text" />
                    </div>
                    <div class="form-group">
                        <select name="city" class="form-control">
                            <option value="">Select City</option>
                            <?php
                            foreach ($cities as $city) {
                                echo "<option value='" . $city["city_name"] . "'>" . strtoupper($city["city_name"]) . "</option>";
                            }
                            ?>                            
                        </select>
                    </div>
                    <div class="form-group ">                       
                        <input type="email" placeholder="Email or Phone" required="" name="email" class="form-control">
                    </div>
                    <div class="form-group ">                       
                        <input type="password" placeholder="Password" required="" name="password" class="form-control">
                    </div>
                    <h5>Upload Property Images <i class="fa fa-hand-o-left" style="cursor:pointer" title="Accepted Format are .jpg, .gif, .png and minimum size is 4MB and minimum dimension allowed 600×900."></i></h5>
                    
                        <span style="color:red;"> Note:- please upload all the 5 photos for better response  </span>
                                <hr style="margin:0px"/>
                    <div class="col-md-12">
                        <div class="form-group ">                       
                            <label>Main Building View</label>
                            <input type="file" name="img" required="" class="form-control">

                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group ">                       
                            <label>Image 1</label>
                            <input type="file" name="img2" class="form-control" required="">

                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group ">                       
                            <label>Image 2</label>
                            <input type="file" name="img3" class="form-control" required="">

                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group ">    
                            <label>Image 3</label>
                            <input type="file" name="img4" class="form-control" required="">

                        </div>
                    </div>  
                    <div class="col-md-12">
                        <div class="form-group ">    
                            <label>Image 4</label>
                            <input type="file" name="img5" class="form-control">

                        </div>
                    </div> 
                    <br clear="all"/>

                </div>
                <div class="col-md-4">               
                    <h5>Price Information</h5>
                    <hr/>

                    <div class="form-group">
                        <label>Room Detail - Single Occupancy</label>                        
                        <div class="col-xs-6">               
                            <input type="text" placeholder="Room Rent" required="" disabled="true" name="room_rent" id="room_rent" class="form-control">
                        </div>
                        <div class="col-xs-6">               
                            <input type="text" placeholder="Security Deposit" required="" disabled="true" name="room_security" id="room_security" class="form-control">
                        </div>                            
                    </div><br clear="all"/><br clear="all"/>
                    <div class="form-group">
                        <label>Room Detail - 2 People Sharing</label>                        
                        <div class="col-xs-6">               
                            <input type="text" placeholder="Room Rent" name="room_rent1[]" value="0" class="form-control rt_class">
                        </div>
                        <div class="col-xs-6">               
                            <input type="text" placeholder="Security Deposit" name="room_security1[]" value="0" class="form-control rt_class">
                        </div>   
                    </div><br clear="all"/><br clear="all"/>
                    <div class="form-group">
                        <label>Room Detail - 3 People Sharing</label>                        
                        <div class="col-xs-6">               
                            <input type="text" placeholder="Room Rent" name="room_rent1[]" value="0" class="form-control rt_class">
                        </div>
                        <div class="col-xs-6">               
                            <input type="text" placeholder="Security Deposit" name="room_security1[]" value="0" class="form-control rt_class">
                        </div>   
                    </div><br clear="all"/><br clear="all"/>
                    <div class="form-group">
                        <label>Room Detail - 4 People Sharing</label>                        
                        <div class="col-xs-6">               
                            <input type="text" placeholder="Room Rent" name="room_rent1[]" value="0" class="form-control rt_class">
                        </div>
                        <div class="col-xs-6">               
                            <input type="text" placeholder="Security Deposit" name="room_security1[]" value="0" class="form-control rt_class">
                        </div>   
                    </div><br clear="all"/><br clear="all"/>
                    <div class="form-group">
                        <label>Room Detail - 5 People Sharing</label>                        
                        <div class="col-xs-6">               
                            <input type="text" placeholder="Room Rent" name="room_rent1[]" value="0" class="form-control rt_class">
                        </div>
                        <div class="col-xs-6">               
                            <input type="text" placeholder="Security Deposit" name="room_security1[]" value="0" class="form-control rt_class">
                        </div>   
                    </div>
                    <br clear="all"/><br clear="all"/>
                    <h5>Facilities</h5>
                    <table width="100%">
                        <tr>
                            <td><input type="checkbox" name="facilities[]" value="tv_room" id="fc1"><label for="fc1" style="display:inline;"> TV | Room</label></td>
                            <td><input type="checkbox" name="facilities[]" value="bed_locker" id="fc2"><label for="fc2" style="display:inline;"> Bed & Locker</label></td>
                            <td><input type="checkbox" name="facilities[]" value="gyeser" id="fc3"><label for="fc3" style="display:inline;"> Gyeser</label></td>
                        </tr>
                        <tr>
                            <td><input type="checkbox" name="facilities[]" value="wather_cooler" id="fc4"><label for="fc4" style="display:inline;"> Water Cooler</label></td>
                            <td><input type="checkbox" name="facilities[]" value="security" id="fc5"><label for="fc5" style="display:inline;"> Security</label></td>
                            <td><input type="checkbox" name="facilities[]" value="power_backup" id="fc6"><label for="fc6" style="display:inline;"> Power Backup</label></td>
                        </tr>
                        <tr>
                            <td><input type="checkbox" name="facilities[]" value="parking" id="fc7"><label for="fc7" style="display:inline;"> Parking</label></td>
                            <td><input type="checkbox" name="facilities[]" value="24_water" id="fc8"><label for="fc8" style="display:inline;"> 24×7 water Supply</label></td>
                            <td><input type="checkbox" name="facilities[]" value="housekeeping" id="fc9"><label for="fc9" style="display:inline;"> Housekeeping</label></td>
                        </tr>
                        <tr>
                            <td><input type="checkbox" name="facilities[]" value="ac" id="fc10"><label for="fc10" style="display:inline;"> AC</label></td>
                            <td><input type="checkbox" name="facilities[]" value="cc_camera" id="fc11"><label for="fc11" style="display:inline;"> CCTV camera</label></td>
                            <td><input type="checkbox" name="facilities[]" value="laundry" id="fc12"><label for="fc12" style="display:inline;">Laundry</label></td>
                        </tr>
                        <tr>
                            <td><input type="checkbox" name="facilities[]" value="kitchen" id="fc13"><label for="fc13" style="display:inline;"> Kitchen</label></td>
                            <td><input type="checkbox" name="facilities[]" value="table_chair" id="fc14"><label for="fc14" style="display:inline;"> Table | Chair</label></td>
                            <td><input type="checkbox" name="facilities[]" value="refrigenerator" id="fc15"><label for="fc15" style="display:inline;"> Refrigerator</label></td>
                        </tr>
                        <tr>
                            <td colspan="3"><input type="checkbox" name="facilities[]" value="wifi" id="fc1"><label for="fc1" style="display:inline;"> Wifi</label></td>
                        </tr>
                    </table>
                    <br clear="all"/>
                    <h5>House Rules</h5>
                    <table width="100%">
                        <tr>
                            <td><input type="checkbox" name="house_rule[]" value="guardian_entry" id="hr1"><label for="hr1" style="display:inline;"> Guardian Entry</label></td>
                            <td><input type="checkbox" name="house_rule[]" value="girl_entry" id="hr2"><label for="hr2" style="display:inline;"> Girls Entry</label></td>
                            <td><input type="checkbox" name="house_rule[]" value="non_veg" id="hr3"><label for="hr3" style="display:inline;"> Non Veg</label></td>
                        </tr>
                        <tr>
                            <td><input type="checkbox" name="house_rule[]" value="drinking" id="hr4"><label for="hr4" style="display:inline;"> Drinking</label></td>
                            <td><input type="checkbox" name="house_rule[]" value="smoking" id="hr5"><label for="hr5" style="display:inline;"> Smoking</label></td>
                            <td><input type="checkbox" name="house_rule[]" value="boy_entry" id="hr6"><label for="hr6" style="display:inline;"> Boys Entry</label></td>
                        </tr>
                        <tr>
                            <td><input type="checkbox" name="house_rule[]" value="entry_9pm" id="hr7"><label for="hr7" style="display:inline;"> Entry Till 9PM</label></td>
                            <td><input type="checkbox" name="house_rule[]" value="entry_10pm" id="hr8"><label for="hr8" style="display:inline;"> Entry Till 10PM</label></td>
                            <td><input type="checkbox" name="house_rule[]" value="entry_11pm" id="hr9"><label for="hr9" style="display:inline;"> Entry Till 11PM</label></td>
                        </tr>
                    </table>
                    <br/>
                    <h5>Food Type</h5>
                    <hr style="margin:0px"/>
                    <div class="form-group">
                        <input type="checkbox" name="food_type[]" value="veg" id="food_veg" > <label for="food_veg" style="display:inline;">Veg </label>&nbsp;&nbsp;&nbsp;
                        <input type="checkbox" name="food_type[]" value="non_veg" id="food_nonveg"> <label for="food_nonveg" style="display:inline">Non Veg </label>
                    </div>
                    <h5>Meals</h5>
                    <hr style="margin:0px"/>
                    <div class="form-group">
                        <input type="checkbox" name="meals[]" value="breakfast" id="meals_breakfast" > <label for="meals_breakfast" style="display:inline;">Breakfast </label>&nbsp;&nbsp;&nbsp;
                        <input type="checkbox" name="meals[]" value="lunch" id="meals_lunch"> <label for="meals_lunch" style="display:inline">Lunch</label>&nbsp;&nbsp;&nbsp;
                        <input type="checkbox" name="meals[]" value="dinner" id="meals_dinner" > <label for="meals_dinner" style="display:inline;">Dinner </label>&nbsp;&nbsp;&nbsp;
                        <input type="checkbox" name="meals[]" value="tea" id="meals_tea"> <label for="meals_tea" style="display:inline">Tea</label>&nbsp;&nbsp;&nbsp;<br/>
                        <input type="checkbox" name="meals[]" value="special" id="special"> <label for="special" style="display:inline">Special</label>&nbsp;&nbsp;&nbsp;
                    </div>
                    <br clear="all"/>
                   
                    <br clear="all"/>

                    <script type="text/javascript">
                        function check_conditions()
                        {

                            if (document.getElementById("check_conditions1").checked == false)
                            {
                                $(document).ready(function() {
                                    $("#btn_submit").attr("disabled", true);
                                });
                            }
                            if (document.getElementById("check_conditions1").checked == true)
                            {
                                $(document).ready(function() {
                                    $("#btn_submit").attr("disabled", false);
                                });
                            }
                        }
                    </script>
                    <p><input type="checkbox" id="check_conditions1" onclick="check_conditions()" id="term&condition"> <label for="term&condition" style="display:inline">I accept <a href="<?php echo base_url(); ?>home/term_condition"><font color="red">Terms & Conditions</font></a> & Privacy Policy.</label></p>
                    <br clear="all"/>
                    <center> <input type="submit" value="Sign up" id="btn_submit" disabled="true" class="btn btn-primary"></center>
                    <div style="form-group">
                        <input id="lat" name="lat" type="hidden" /><br/>
                        <input id="long" name="long" type="hidden" /><br/>
                        <br/>
                    </div>
                </div>

            </form> 
            <script src="http://maps.google.com/maps/api/js?sensor=false" type="text/javascript"></script>
            <script type='text/javascript'>
                        window.onload = function() {
                            // find DOM elements
                            var latField = document.getElementById('lat');
                            var lngField = document.getElementById('long');
                            var canvas = document.getElementById('map');
                            var form = document.getElementById('addressForm');
                            var addressField = document.getElementById('map_address');
                            // create map, marker, infowindow and geocoder objects
                            var options = {
                                zoom: 14,
                                center: new google.maps.LatLng(37.09, -95.71),
                                mapTypeId: google.maps.MapTypeId.ROADMAP
                            };
                            var map = new google.maps.Map(canvas, options);
                            var marker = new google.maps.Marker({
                                map: map
                            });
                            var infowindow = new google.maps.InfoWindow();
                            var geocoder = new google.maps.Geocoder();
                            // set handler for form.onsubmit event
                            form.onsubmit = function() {
//                                document.getElementById("main_address").value = addressField.value;
                                return showAddressOnMap(addressField.value);
                            }
                            // worker function to display marker on map at address
                            function showAddressOnMap(address) {
                                try {
                                    var geocoderRequest = {
                                        address: address
                                    }
                                    geocoder.geocode(geocoderRequest, function(results, status) {
                                        if (status == google.maps.GeocoderStatus.OK) {
                                            var location = results[0].geometry.location;
                                            map.setCenter(location);
                                            marker.setPosition(location);
                                            var content = [];
                                            content.push('<strong>' + results[0].formatted_address + '</strong>');
                                            content.push('Lat: ' + location.lat());
                                            content.push('Lng: ' + location.lng());
                                            infowindow.setContent(content.join('<br/>'));
                                            infowindow.open(map, marker);
                                            latField.value = location.lat();
                                            lngField.value = location.lng();
                                        }
                                    });
                                    return false;
                                }
                                catch (e) {
                                    return false;//ensure form does not submit, even if there's an error
                                }
                            }
                        };
            </script>
            <div class="col-md-4">     
                <h5>Set Your Location On Map</h5>
                <span style="color:red; ">Note:- Please set your location on map for better response</span>
                <hr/>
                <div class="form-group ">
                    <form id="addressForm" style="margin:10px 0;">
                        <input type="text" required="" placeholder="Enter your location Area, City, State"   id="map_address" class="form-control">
                        <br clear="all"/>
                        <input type="submit" value="submit" class="btn btn-primary">
                    </form>
                </div>
                <div id="map" style="width:100%;height:350px;border:1px solid #999;"></div>
                <br clear="all">
                <h5>Instructions</h5>
                <ul>
                    <li>Are you facing any problem in filling the Online Form?</li>
                    <li>Please do let us know.</li>
                    <li>We are happy to help you</li>
                    <li>Contact Us :-<br/>                        
                        +91-9479421082<br/>
                        +91-9138100676
                    </li>
                    <li>Email : info@hostelnetwork.in</li>
                </ul>
            </div>




        </div>

    </div>
    <div class="gap gap-small"></div>
</div>




