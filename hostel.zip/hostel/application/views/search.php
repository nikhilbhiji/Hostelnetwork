<?php error_reporting(0); ?>

<!-- TOP AREA -->
<div class="top-area show-onload" style="height:250px;">
    <div class="bg-holder full">
        <div class="bg-mask"></div>
        <div class="bg-parallax" style="background-image:url(<?php echo base_url(); ?>includes/img/DSC00994.jpg);"></div>
        <div class="bg-content">
            <div class="container" >
                <div class="row">
                    <div class="col-md-12" style="margin-top:10px;">             
                        <h1 style="color:white;text-align:center;">One stop solution to Hostel/PG Finding Queries</h1>
                    </div>
                    <div class="col-md-12">
                        <h4 class="city__amenities__heading">Basic Facilities in HostelNetwork</h4>
                    </div>
                    <div class="col-md-12">
                        <div class="city__amenities__block">
                            <div class="hero__amenities__wrapper">
                                <span class="hero__amenities__element hero__amenities__bed"></span>
                                <span class="hero__amenities__element--text ">Bed</span>
                            </div>
                            <div class="hero__amenities__wrapper">
                                <span class="hero__amenities__element hero__amenities__locker"></span>
                                <span class="hero__amenities__element--text ">Locker</span>
                            </div>
                            <div class="hero__amenities__wrapper">
                                <span class="hero__amenities__element hero__amenities_washrooms"></span>
                                <span class="hero__amenities__element--text ">Clean Washrooms</span>
                            </div>
                            <div class="hero__amenities__wrapper">
                                <span class="hero__amenities__element hero__amenities__24_hour"></span>
                                <span class="hero__amenities__element--text ">24 Hour Water & Electricity</span>
                            </div>
                            <div class="hero__amenities__wrapper">
                                <span class="hero__amenities__element hero__amenities__security"></span>
                                <span class="hero__amenities__element--text ">Security</span>
                            </div>
                            <div class="hero__amenities__wrapper">
                                <span class="hero__amenities__element hero__amenities__parking"></span>
                                <span class="hero__amenities__element--text ">Parking</span>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- END TOP AREA  -->

<div class="container">
    <div class="row row-wrap" data-gutter="60">
        <div class="col-md-9" style="float:right">
            <br clear="all"/>
            <h5 style="text-transform:capitalize">
                Location : <?php echo $_GET["location"]; ?> &nbsp;&nbsp;&nbsp;&nbsp;
                Sort by : <?php echo $_GET["gender"]; ?>&nbsp;&nbsp;&nbsp;&nbsp;
                Price : <?php echo $_GET["price_range"]; ?>/<span style="text-transform:lowercase;">m</span>&nbsp;&nbsp;&nbsp;&nbsp;
                Property Type : <?php echo $_GET["property_type"]; ?>&nbsp;&nbsp;&nbsp;&nbsp;
            </h5>
        </div>

        <div class="col-md-3">
            <div class="hero__searchbar homeSearchbar">
                <h3>Search Fields</h3>
                <hr/>                
                <form id="js-search-form" method="GET" action="<?php echo base_url(); ?>home/search">
                    <div class="form-group">
                        <label>Location</label>
                        <input type="text" name="location" class="form-control" placeholder="Select City, Locality, Landmark or Pincode" value="<?php if (isset($_GET["location"])) echo $_GET["location"]; ?>"/>
                    </div>
                    <script type="text/javascript">
                        function change_range()
                        {
                            document.getElementById("range_max").innerText = document.getElementById("range_control").value + "/m";
                        }
                    </script>
                    <div class="form-group">
                        <label>Price</label>
                        <input type="range" calss="form-control" min="0" name="price_range" id="range_control" max="50000" onchange="change_range()" value="<?php if (isset($_GET["location"])) echo $_GET["price_range"]; ?>"/>
                        <label  style="color:black;display:inline">Price : </label>
                        <!--                                                <label id="range_min" style="color:white;display:inline">4</label>-->
                        <label id="range_max" style="color:black;float:right;display:inline"><?php
                            if (isset($_GET["location"]))
                                echo $_GET["price_range"] + "/m";
                            else
                                echo "25000/m";
                            ?></label>
                    </div>
                    <div class="form-group">
                        <label>Property For</label>
                        <input type="radio" value="male" name="gender" <?php
                        if (isset($_GET["gender"])) {
                            if ($_GET["gender"] == "male")
                                echo "checked";
                        }
                        ?> id="male" > <label for="male" style="display:inline;">Male </label><br/>
                        <input type="radio" value="female" name="gender" <?php
                        if (isset($_GET["gender"])) {
                            if ($_GET["gender"] == "female")
                                echo "checked";
                        }
                        ?> id="female"> <label for="female" style="display:inline">Female </label>
                    </div>
                    <div class="form-group">
                        <label>Property Type</label>
                        <input type="radio" name="property_type" <?php if ($_GET["property_type"] == "hostel") echo "checked"; ?> value="hostel" id="hostel_type" > <label for="hostel_type" style="display:inline;">Hostel </label><br/>
                        <input type="radio" name="property_type" <?php if ($_GET["property_type"] == "pg") echo "checked"; ?> value="pg" id="pg_type"> <label for="pg_type" style="display:inline">P.G.</label><br/>
                        <input type="radio" name="property_type" <?php if ($_GET["property_type"] == "room") echo "checked"; ?> value="room" id="room_type"> <label for="room_type" style="display:inline">Room</label>
                    </div>
                    <div class="form-group">
                        <label>Occupancy</label>
                        <input type="radio" name="occupancy" <?php if ($_GET["occupancy"] == "single") echo "checked"; ?> value="single" id="hostel_type" > <label for="single" style="display:inline;">Single</label><br/>
                        <input type="radio" name="occupancy" <?php if ($_GET["occupancy"] == "sharing") echo "checked"; ?> value="sharing" id="pg_type"> <label for="sharing" style="display:inline">Sharing</label><br/>
                    </div>
                    <div class="form-group">
                        <label>Food Type</label>
                        <input type="radio" name="food_type" <?php if ($_GET["food_type"] == "veg") echo "checked"; ?> value="veg" id="veg" > <label for="veg" style="display:inline;">Veg</label><br/>
                        <input type="radio" name="food_type" <?php if ($_GET["food_type"] == "non-veg") echo "checked"; ?> value="non-veg" id="non-veg"> <label for="non-veg" style="display:inline">Non Veg</label><br/>
                    </div>
                    <div class="col-md-12">
                        <input type="submit" value="Search" class="btn btn-primary" style="width:100%"/>
                    </div>
                </form>
            </div>
        </div>
        <style>
            body{width:610;}
            .demo-table
            {
                float:left;
            }
            .demo-table th {background: #32C2DB;padding: 5px;text-align: left;color:#FFF;}

            .demo-table td div.feed_title{text-decoration: none;color:#00d4ff;font-weight:bold;}
            .demo-table ul{float:left;list-style-type:none;padding:0px;}
            .demo-table li{cursor:pointer;list-style-type:none;display: inline-block;color: #F0F0F0;text-shadow: 0 0 1px #666666;font-size:20px;}
            .demo-table .highlight, .demo-table .selected {color:#F4B30A;text-shadow: 0 0 1px #F48F0A;}
        </style>
        <div class="col-md-8">
            <?php
            if (count($hostels) > 0) {
                $u = 1;
                $i = 0;
                foreach ($hostels as $hostel) {
                    ?>

                    <a href="<?php echo base_url(); ?>home/more_detail?id=<?php echo $hostel["id"] ?>">
                        <div class="col-md-6 signle-products"    rel="product<?php echo $i; ?>" style="height:250px;width:360px;margin-right:10px;margin-bottom:10px;" >

                            <img onmouseover="display_property('product<?php echo $u; ?>')"  src="<?php echo base_url() ?>includes/upload/thimg/<?php echo $hostel["img"] ?>" style="z-index:1;position:absolute;border-radius:10px;min-height:200px;height:250px; filter: brightness(70%);" class="img-thumbnail"/>

                            <div style="position:absolute;top:10px;color:white;">helo</div>
                            <center>
                                <br clear="all"/>
                                <table class="" width="95%" style="z-index:5;position:absolute;color:white;margin-left:10px;font-size:17px;text-transform:capitalize;" >
                                    <tr>
                                        <td >
                                            <?php
                                            if ($hostel["property_for"] == "male") {
                                                ?>
                                                <i class="fa fa-male"></i>
                                                <?php
                                            } else {
                                                ?>
                                                <i class="fa fa-female"></i>
                                                <?php
                                            }
                                            ?>
                                            <?php echo substr($hostel["property_for"], 0, 1); ?></td>
                                        <td align="right" width="35%"><span style="border:1px white solid;padding:4px;border-radius:2px;"><?php echo $hostel["property_type"]; ?></span></td>
                                    </tr>
                                    <tr height="130px">
                                        <td colspan="2"></td>
                                    </tr>
                                    <tr>
                                        <td ><?php echo $hostel["occupancy"] ?></td> <td>&nbsp;&nbsp;₹ <?php
                                    if($hostel["occupancy"] != "sharing")
                                    {
                                    echo $hostel["room_rent"]; 
                                    }
                                    else
                                    {
                                        $rent_ex = explode("#", $hostel["room_rent1"]);
                                       
                                        echo $rent_ex[0];
                                    }
                                            ?>/<span style="text-transform:lowercase;">m</span></td>
                                    </tr>
                                    <tr>
                                        <td> Views : <?php echo $hostel["views"] ?></td>
                                        <td> <label style="float:left;display:inline-block"></label>
                                            <table class="demo-table" align="center">
                                                <td>
                                                    <ul>
                                                        <?php
                                                        for ($i = 1; $i <= 5; $i++) {
                                                            if ($i <= $hostel["total_rating"]) {
                                                                ?>
                                                                <li class="selected">&#9733;</li>
                                                                <?php
                                                            } else {
                                                                ?>
                                                                <li>&#9733;</li>
                                                                <?php
                                                            }
                                                        }
                                                        ?>

                                                    </ul>
                                                </td>
                                            </table>
                                        </td>
                                    </tr>
                                </table>   
                            </center>


                        </div>


                        <div class="col-md-6 signle-products"    rel="product<?php echo $i; ?>" style="height:250px;width:340px;margin-right:10px;margin-bottom:10px;border:1px grey solid;margin-left:20px;border-radius:10px;" >

                            <style>
                                table td{
                                    word-break:break-all;
                                    padding-left:7px;
                                }
                            </style>
                            <h5 align="center" style="margin-top:5px;">Owner Details</h5>
                            <table align="center" width="100%"  class="table table-hover"  style="z-index:5;color:grey;font-size:14px;text-transform:capitalize;" >

                                <tr>
                                    <td width="50%">Owner Name</td>
                                    <td><?php echo $hostel["owner_name"] ?></td>
                                </tr>                                    
                                <tr>
                                    <td>Property Name</td>
                                    <td><?php echo $hostel["property_name"] ?></td>
                                </tr>          


                                <tr>
                                    <td>Contact No.</td>
                                    <td><?php echo $hostel["mobile_no"] ?></td>
                                </tr>     
                                <tr>
                                    <td>Address</td>
                                    <td><?php echo $hostel["location"] ?></td>
                                </tr>   
                            </table> <hr/>
                        </div>
                    </a>
                    <hr/>
            
                    <?php
                    if ($i == 1) {
                        echo "<br clear='all'/><br clear='all'/>";
                        $i = 0;
                    }
                    $i++;
                    $u++;
                }
            } else {
                echo "<h3>No Record Found</h3>";
            }
            ?>

        </div>
    </div>
    <div class="gap gap-small"></div>
    <script type="text/javascript">
        function display_property(el)
        {
            $(document).ready(function() {
                $(".product-overlay").css({display: "block"});
                $("." + el).animate({height: "250px"}, 500);
            });
            //setTimeout("hide_property('"+el+"')",2000);
        }
        function hide_property(el)
        {
            $("." + el).animate({height: "0px"}, 500);
        }

    </script>
</div>




