

<br clear="all"/>

<div class="container">
    <div class="row " >   
        <div class="col-md-12">
            <div class="col-md-12">                
                <?php
                if ($this->session->flashdata('signup')) {
                    echo "<div class='alert alert-success'><i class='entypo-check'></i> " .
                    $this->session->flashdata('signup') .
                    "</div>";
                }
                if ($this->session->flashdata('notify')) {
                    echo "<div class='alert alert-danger'><i class='entypo-check'></i> " .
                    $this->session->flashdata('notify') .
                    "</div>";
                }
                ?>
            </div>
            <form action="<?php echo base_url();?>home/forget_password_action" method="post">
                <div class="col-md-6">   
                    <h3 class="mb15">Login</h3>
                    <hr/>
                    <div class="form-group ">
                        <input type="email" name="email" placeholder="Email Id" class="form-control"/>
                    </div>                               
                    <div class="form-group ">
                        <input type="submit" name="submit" class="btn btn-primary" value="Login"/>
                    </div>
                    <a href="<?php echo base_url();?>home/forget_password">Forget Password?</a>
                </div>

            </form>                                  
        </div>

    </div>
    <div class="gap gap-small"></div>
</div>




