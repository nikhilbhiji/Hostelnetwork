

<br clear="all"/>

<div class="container">
    <div class="row " >   
        <div class="col-md-3">
            <?php include("head_nav.php");?>
        </div>
        <div class="col-md-9">
            <h1>Welcome In Admin Panel</h1>                       
        </div>

    </div>
    <div class="gap gap-small"></div>
</div>




