

<br clear="all"/>

<div class="container">
    <div class="row " >   
        <div class="col-md-12">
            <div class="col-md-12">                
                <?php
                if ($this->session->flashdata('signup')) {
                    echo "<div class='alert alert-success'><i class='entypo-check'></i> " .
                    $this->session->flashdata('signup') .
                    "</div>";
                }
                if ($this->session->flashdata('notify')) {
                    echo "<div class='alert alert-danger'><i class='entypo-check'></i> " .
                    $this->session->flashdata('notify') .
                    "</div>";
                }
                ?>
            </div>

                <div class="col-md-12">   
                    <h3 class="mb15">Privacy Policy</h3>
                    <hr/>

                    <p>Thanks for reviewing our privacy policy.</p>
<p>We consider your privacy to be very important. All information provided by you will be kept strictly confidential and will not be disclosed to any third party, without your permission, except to the hostel owners or in the event wherein you communicate with the hostel owner’s directly. We have accordingly developed this privacy policy to protect your personal information and keep it confidential. We follow stringent procedures to help protect the confidentiality, security, and integrity of data stored on our systems.
</p>

<h5>Anti-Spam Policy</h5>
<p>Any E Mail addresses supplied by you will not be sold to third parties. If a user wishes to subscribe to our newsletters, we ask for contact information such as name and email address, which will never be disclosed to any external sources.
</p>

<h5>Surveys & Contests</h5>
<p>From time-to-time our website requests information from users via surveys or contests. Participation in these surveys or contests is completely voluntary and the user therefore has a choice whether or not to disclose this information.
Information requested may include contact information (such as name and postal address), and demographic information (such as postal code, age, gender, etc.)
</p>

<h5>Sharing</h5>
<p>Where partnerships with other companies are formed, we will share aggregated demographic information with them. This is not linked to any personal information that can identify any individual person.
We may partner with another party to provide specific services. When the user signs up for these services, we will share names, or other contact information that is necessary for the third party to provide these services.
To provide better information hostelnetwork.in owned the rights to share Visitor’s contact detail with one or many parties.
These parties are not allowed to use personally identifiable information except for the purpose of providing these services.
</p>

<h5>External Links</h5>

<p>This site, our Emails, and other electronic publications contain links to other sites. Our company is not responsible for the privacy practices or the content of such websites.
    
Notification of Changes

If we decide to change our Privacy Policy, we will post those changes on our Homepage so our users are always aware of what information we collect, how we use it, and under what circumstances, if any, we disclose it.
If at any point we decide to use personally identifiable information in a manner different from that stated at the time it was collected, we will notify users by way of an email.
Users will have a choice as to whether or not we use their information in this different manner. We will use information in accordance with the Privacy Policy under which the information was collected.
For Site security purposes and to ensure that our Services remain available to all users, we employ software programs to monitor traffic to identify unauthorized attempts to upload or change information or otherwise cause damage. Notwithstanding anything stated above, we reserve the right to use information from these sources to help identify an individual or prosecute malicious use or misuse of the Site.
Your account information is password-protected for your privacy and security. In certain areas, as with credit card transactions, our Site uses industry-standard secure socket layer (SSL) encryption to protect data transmissions.
</p>
<h5>Kids' Safety and Privacy</p>

<p>The Site is not directed to person under the age of 18, and does not knowingly collect personal information from children.</p>
















                </div>


        </div>

    </div>
    <div class="gap gap-small"></div>
</div>




