<!DOCTYPE HTML>
<html>

    <head>
        <title>Hostel Networks</title>
        <meta content="text/html;charset=utf-8" http-equiv="Content-Type">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="author" content="Tsoy">
        <link rel="shortcut icon" href="<?php echo base_url(); ?>includes/img/favicon.png"/>
        <link rel="stylesheet" href="<?php echo base_url(); ?>includes/css/bootstrap.css">
        <link rel="stylesheet" href="<?php echo base_url(); ?>includes/css/font-awesome.css">
        <link rel="stylesheet" href="<?php echo base_url(); ?>includes/css/icomoon.css">
        <link rel="stylesheet" href="<?php echo base_url(); ?>includes/css/styles.css">
        <link rel="stylesheet" href="<?php echo base_url(); ?>includes/css/mystyles.css">
        <script src="<?php echo base_url(); ?>includes/js/modernizr.js"></script>

        <link rel="stylesheet" href="<?php echo base_url(); ?>includes/css/switcher.css" />
        <link rel="alternate stylesheet" type="text/css" href="<?php echo base_url(); ?>includes/css/schemes/bright-turquoise.css" title="bright-turquoise" media="all" />
        <link rel="alternate stylesheet" type="text/css" href="<?php echo base_url(); ?>includes/css/schemes/turkish-rose.css" title="turkish-rose" media="all" />
        <link rel="alternate stylesheet" type="text/css" href="<?php echo base_url(); ?>includes/css/schemes/salem.css" title="salem" media="all" />
        <link rel="alternate stylesheet" type="text/css" href="<?php echo base_url(); ?>includes/css/schemes/hippie-blue.css" title="hippie-blue" media="all" />
        <link rel="alternate stylesheet" type="text/css" href="<?php echo base_url(); ?>includes/css/schemes/mandy.css" title="mandy" media="all" />
        <link rel="alternate stylesheet" type="text/css" href="<?php echo base_url(); ?>includes/css/schemes/green-smoke.css" title="green-smoke" media="all" />
        <link rel="alternate stylesheet" type="text/css" href="<?php echo base_url(); ?>includes/css/schemes/horizon.css" title="horizon" media="all" />
        <link rel="alternate stylesheet" type="text/css" href="<?php echo base_url(); ?>includes/css/schemes/cerise.css" title="cerise" media="all" />
        <link rel="alternate stylesheet" type="text/css" href="<?php echo base_url(); ?>includes/css/schemes/brick-red.css" title="brick-red" media="all" />
        <link rel="alternate stylesheet" type="text/css" href="<?php echo base_url(); ?>includes/css/schemes/de-york.css" title="de-york" media="all" />
        <link rel="alternate stylesheet" type="text/css" href="<?php echo base_url(); ?>includes/css/schemes/shamrock.css" title="shamrock" media="all" />
        <link rel="alternate stylesheet" type="text/css" href="<?php echo base_url(); ?>includes/css/schemes/studio.css" title="studio" media="all" />
        <link rel="alternate stylesheet" type="text/css" href="<?php echo base_url(); ?>includes/css/schemes/leather.css" title="leather" media="all" />
        <link rel="alternate stylesheet" type="text/css" href="<?php echo base_url(); ?>includes/css/schemes/denim.css" title="denim" media="all" />
        <link rel="alternate stylesheet" type="text/css" href="<?php echo base_url(); ?>includes/css/schemes/scarlet.css" title="scarlet" media="all" />
        <script type="text/javascript">
            var base_url = "<?php echo base_url(); ?>";
        </script>
    </head>

    <body>


        <div class="global-wrap">

            <header id="main-header">
                <div class="header-top">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-6">

                                <a class="logo" href="<?php echo base_url(); ?>">                                    
<!--                                    <div style="float:left;height:40px;"><i class="fa fa-angle-up" style="color:white;font-size:40px;margin-top:-5px;margin-right:10px"></i></div><font color="white" size="5">Hostel Network</font>
                                    <br/>
                                    <span style="color:white;">Social Network Of Hostels/PGs</span>-->
                                    <img src="<?php echo base_url(); ?>includes/img/logo.png" height="50px" style="margin-top:-5px;"/>
                                </a>
                            </div>                     
                            <div class="col-md-6">
                                <div class="top-user-area clearfix">
                                    <ul class="top-user-area-list list list-horizontal list-border">

                                        <li class="nav-drop"><a href="#">Register Your Hostel/PG Free <i class="fa fa-angle-down"></i><i class="fa fa-angle-up"></i></a>
                                            <ul class="list nav-drop-menu">
                                                <li><?php
                                                    if ($this->session->userdata("user") != "") {
                                                        ?>
                                                        <a href="<?php echo base_url(); ?>home/profile">My Account (
                                                            <?php echo $this->session->userdata("user"); ?>)
                                                        </a>
                                                        <a  href="<?php echo base_url(); ?>home/check_booking">
                                                            Check Bookings
                                                        </a>
                                                        <?php
                                                    } else {
                                                        ?>
                                                        <a href="<?php echo base_url(); ?>home/login">
                                                            Login
                                                        </a>
                                                        <?php
                                                    }
                                                    ?>
                                                </li>
                                                <li>
                                                    <?php
                                                    if ($this->session->userdata("user") != "") {
                                                        ?>
                                                        <a href="<?php echo base_url(); ?>home/logout">Logout</a>
                                                        <?php
                                                    } else {
                                                        ?>
                                                        <a  href="<?php echo base_url(); ?>home/signup">Register</a>
                                                        <?php
                                                    }
                                                    ?>
                                                </li>                                             

                                            </ul>
                                        </li>
                                        <li class="top-user-area-lang nav-drop">
                                            <a href="#">
                                                <i class="hero__amenities__element hero__amenities__24_hour1"></i><span style="position:absolute;">9479421082</span>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="container">
                    <div class="nav">
                        <ul class="slimmenu" id="slimmenu">
                            <li class="active"><a href="<?php echo base_url(); ?>home/search?location=jabalpur">Jabalpur</a>

                            </li>                                        
                            <li class="active"><a href="<?php echo base_url(); ?>home/search?location=bhopal">Bhopal</a>

                            </li> 
                            <li class="active"><a href="<?php echo base_url(); ?>home/search?location=indore">Indore</a>

                            </li> 
                            <li class="active"><a href="<?php echo base_url(); ?>home/search?location=gwalior">Gwalior</a>

                            </li> 
                            <li class="active"><a href="<?php echo base_url(); ?>home/search?location=ludhiana">Ludhiana</a>

                            </li> 
                            <li class="active"><a href="<?php echo base_url(); ?>home/all_cities">All Cities</a>

                            </li> 
                        </ul>
                    </div>
                </div>
            </header>