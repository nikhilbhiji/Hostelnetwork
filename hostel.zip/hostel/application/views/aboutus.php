

<br clear="all"/>

<div class="container">
    <div class="row " >   
        <div class="col-md-12">
            <div class="col-md-12">                
                <?php
                if ($this->session->flashdata('signup')) {
                    echo "<div class='alert alert-success'><i class='entypo-check'></i> " .
                    $this->session->flashdata('signup') .
                    "</div>";
                }
                if ($this->session->flashdata('notify')) {
                    echo "<div class='alert alert-danger'><i class='entypo-check'></i> " .
                    $this->session->flashdata('notify') .
                    "</div>";
                }
                ?>
            </div>
            <form action="<?php echo base_url();?>home/login_action" method="post">
                <div class="col-md-12">   
                    <h3 class="mb15">About Us</h3>
                    <hr/>
                    <p>HostelNetwork.in provide you with on in-depth & much needed information about hostels around you. We strive hard to provide you everything that you might want to know about hostels like Facilities, Meals, Address, Pictures, Reviews & Ratings.</p>
                    <p>Our Platform is Indeed a great alternative to physical searching for hostel seekers. We offer a value proposition that is beneficial for hostel seekers & our partners(Hostel Owners) purely with Passion & Technology as our weapons.</p>
                    <p>At HostelNetwork.in, were proud to say that no other website offer a better search experience than ours. We pride ourselves on resulting the best hostels from the largest selection of hostels.</p>
                    <p>Hostelnetwork.in has an extensive network that help us to provide complete information on the widest range of hostels around you. We have make comparison between hostels so easy that we can gurantee that you get. The best hostel at the best price.</p>
                </div>

            </form>                                  
        </div>

    </div>
    <div class="gap gap-small"></div>
</div>




