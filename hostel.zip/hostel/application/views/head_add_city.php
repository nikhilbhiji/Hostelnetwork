

<br clear="all"/>

<div class="container">
    <div class="row " >   
        <div class="col-md-3">
            <?php include("head_nav.php");?>
        </div>
        <div class="col-md-6">
            <h4>Add City</h4>
            <hr/>
            <form action="<?php echo base_url();?>head/add_city_action" method="post">                      
                <div class="form-group">
                    <label>Enter City</label>
                    <input type="text" name="city_name" class="form-control" placeholder="Enter City Name"/>
                    
                </div>
                <input type="submit" name="submit" class="btn btn-primary" value="Submit"/>
                    
            </form>
        </div>

    </div>
    <div class="gap gap-small"></div>
</div>




