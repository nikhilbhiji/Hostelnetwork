
<?php
//for undefined variables
error_reporting(0);
?>
<br clear="all"/>
<link rel='stylesheet' id='jquery-fancybox-css'  href='<?php echo base_url(); ?>includes/fancybox/jquery.fancybox.css' type='text/css' media='all' />        
<div class="container">
    <div class="row row-wrap" data-gutter="60">   
        <div class="col-md-12">
            <div class="col-md-12">
                <?php
                if ($this->session->flashdata('review')) {
                    echo "<div class='alert alert-success'><i class='entypo-check'></i> " .
                    $this->session->flashdata('review') .
                    "</div>";
                }
                ?>
            </div>
            <!--            <div class="col-md-6">
                            <div class="block block-transparent">
                                <link rel="stylesheet" href="<?php echo base_url(); ?>includes/slider/css/smoothslides.theme.css">
                                <div class="smoothslides " id="myslideshow1">	
                                    <img src="<?php echo base_url(); ?>includes/slider/images/1.jpg"/>
                                    <img src="<?php echo base_url(); ?>includes/slider/images/2.jpg"/>
                                    <img src="<?php echo base_url(); ?>includes/slider/images/3.jpg"/>
                                    <img src="<?php echo base_url(); ?>includes/slider/images/4.jpg"/>
                                </div>
                                <script type="text/javascript" src="<?php echo base_url(); ?>includes/slider/js/smoothslides-2.1.0.min.js"></script>
                                <script type="text/javascript">s
                                    $(window).load(function() {
                                        $('#myslideshow1').smoothSlides({
                                            pagination: 'false',
                                            effect: 'zoomIn,zoomOut,panLeft,panRight'
                                        });
                                    });
                                                        </script>
                            </div>
                        </div>-->
            <div class="col-md-6">
                <?php
                $img = array();
                $img[] = "'" . $hostel["img"] . "'";
                if (!empty($hostel["img2"])) {
                    $img[] = "'" . $hostel["img2"] . "'";
                }
                if (!empty($hostel["img3"])) {
                    $img[] = "'" . $hostel["img3"] . "'";
                }
                if (!empty($hostel["img4"])) {
                    $img[] = "'" . $hostel["img4"] . "'";
                }
                if (!empty($hostel["img5"])) {
                    $img[] = "'" . $hostel["img5"] . "'";
                }
                $imgary = implode(",", $img);
                ?>
                <script type="text/javascript">
                    var s = new Array(<?php echo $imgary; ?>);
                    var i = 0;
                    function fun_slider()
                    {
                        document.getElementById("total_images").innerHTML = s.length;
                        document.getElementById("left_images").innerHTML = 1;
                        //    document.getElementById("slider").src = "<?php echo base_url() ?>includes/upload/thimg/" + s[i];
//                        document.getElementById("slider_href").href = "<?php echo base_url() ?>includes/upload/" + s[i];
                    }
                    function next_image()
                    {
                        if (i < s.length - 1)
                        {
                            i++;
                            document.getElementById("slider_href").href = "<?php echo base_url() ?>includes/upload/" + s[i];
                            document.getElementById("slider").src = "<?php echo base_url() ?>includes/upload/thimg/" + s[i];
                            document.getElementById("left_images").innerHTML = i + 1;
                        }
                    }
                    function previous_image()
                    {
                        if (i >= 1)
                        {
                            i--;
                            document.getElementById("slider_href").href = "<?php echo base_url() ?>includes/upload/" + s[i];
                            document.getElementById("slider").src = "<?php echo base_url() ?>includes/upload/thimg/" + s[i];
                            document.getElementById("left_images").innerHTML = i + 1;
                        }
                    }
                </script>
                <a href="<?php echo base_url() ?>includes/upload/<?php echo $hostel["img"]; ?>" data-fancybox-group="gdlr-gal-1" data-rel="fancybox"  id="slider_href"><img src="<?php echo base_url() ?>includes/upload/thimg/<?php echo $hostel["img"]; ?>" id="slider" class="img-thumbnail" style="height:300px;"></a>
                <div style="position:absolute;font-size:50px;top:130px;left:40px;color:black;width:40px;height:40px;opacity:0.9;color:white;padding-top:5px;cursor:pointer;" onclick="previous_image()" ><i class="fa fa-arrow-circle-o-left"></i></div>
                <div style="position:absolute;font-size:50px;right:40px;top:130px;color:black;width:40px;height:40px;opacity:0.9;color:white;padding-top:5px;cursor:pointer;" onclick="next_image()" ><i class="fa fa-arrow-circle-o-right"></i></div>



                <script type='text/javascript' src='<?php echo base_url() ?>includes/jquery/jquery.js'></script>
                <script type='text/javascript' src='<?php echo base_url() ?>includes/fancybox/jquery.fancybox.pack.js'></script>
                <script type='text/javascript' src='<?php echo base_url() ?>includes/fancybox/helpers/jquery.fancybox-media.js'></script>
                <script type='text/javascript' src='<?php echo base_url() ?>includes/fancybox/helpers/jquery.fancybox-thumbs.js'></script>
                <script type='text/javascript' src='<?php echo base_url() ?>includes/flawless-v1-14/javascript/gdlr-script.js'></script>

                <div style="">
                    Total Images : 
                    <span id="left_images"></span>
                    /
                    <span id="total_images"></span>
                </div>
            </div>
            <div class="col-md-6">
                <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.6.1/jquery.min.js" type="text/javascript"></script>
                <script src="http://maps.google.com/maps/api/js?sensor=true" type="text/javascript"></script>
                <style type="text/css">
                    *{ padding:0; margin:0; }
                    #map_div{
                        width:100%;
                        height:300px;
                        border:6px solid #F4F4F4;

                    }
                </style>
                <script type="text/javascript">
                    $(document).ready(function() {

                        //------- Google Maps ---------//

                        // Creating a LatLng object containing the coordinate for the center of the map
                        var latlng = new google.maps.LatLng(<?php echo $hostel["lat"]; ?>,<?php echo $hostel["long"]; ?>);

                        // Creating an object literal containing the properties we want to pass to the map  
                        var options = {
                            zoom: 15, // This number can be set to define the initial zoom level of the map
                            center: latlng,
                            mapTypeId: google.maps.MapTypeId.ROADMAP // This value can be set to define the map type ROADMAP/SATELLITE/HYBRID/TERRAIN
                        };
                        // Calling the constructor, thereby initializing the map  
                        var map = new google.maps.Map(document.getElementById('map_div'), options);

                        // Define Marker properties
                        var image = new google.maps.MarkerImage('<?php echo base_url(); ?>includes/img/marker.png',
                                // This marker is 129 pixels wide by 42 pixels tall.
                                new google.maps.Size(129, 42),
                                // The origin for this image is 0,0.
                                new google.maps.Point(0, 0),
                                // The anchor for this image is the base of the flagpole at 18,42.
                                new google.maps.Point(18, 42)
                                );

                        // Add Marker
                        var marker1 = new google.maps.Marker({
                            position: new google.maps.LatLng(<?php echo $hostel["lat"]; ?>,<?php echo $hostel["long"]; ?>),
                            map: map,
                            icon: image // This path is the custom pin to be shown. Remove this line and the proceeding comma to use default pin
                        });


                        // Add listener for a click on the pin
                        google.maps.event.addListener(marker1, 'click', function() {
                            infowindow1.open(map, marker1);
                        });


                        // Add information window
                        var infowindow1 = new google.maps.InfoWindow({
                            content: createInfo('Evoluted New Media', 'Ground Floor,<br />35 Lambert Street,<br />Sheffield,<br />South Yorkshire,<br />S3 7BH<br /><a href="http://www.evoluted.net" title="Click to view our website">Our Website</a>')
                        });

                        // Create information window
                        function createInfo(title, content) {
                            return '<div class="infowindow"><strong>' + title + '</strong><br />' + content + '</div>';
                        }

                    });



                </script>

                <div id="map_div">&nbsp;</div>
            </div>

        </div>
        <div class="col-md-12">&nbsp;&nbsp;&nbsp;&nbsp;
            <?php
            if($hostel["occupancy"]=="single")
            {
            ?>
            * Rent : <?php echo $hostel["room_rent"]; ?>  &nbsp;&nbsp;&nbsp;&nbsp;
            * Security Deposit : <?php echo $hostel["room_security"]; ?> &nbsp;&nbsp;&nbsp;&nbsp;
            <?php
            }
            ?>
            * Occupancy : <?php echo $hostel["occupancy"]; ?> &nbsp;&nbsp;&nbsp;&nbsp;
            * Property For : <?php echo $hostel["property_for"]; ?>&nbsp;&nbsp;&nbsp;&nbsp;
            * Property Type : <?php echo $hostel["property_type"]; ?>&nbsp;&nbsp;&nbsp;&nbsp;
        </div>
        <div class="col-md-12">
            <div class="col-md-9">
                <div class="col-md-6">


                    <h3>Facilities</h3>
                    <hr/>
                    <table width="100%">
                        <?php
                        if (strchr($hostel["facilities"], "tv_room") != "") {
                            $tv_room = "checked";
                        }
                        if (strchr($hostel["facilities"], "bed_locker") != "") {
                            $bed_locker = "checked";
                        }
                        if (strchr($hostel["facilities"], "gyeser") != "") {
                            $gyeser = "checked";
                        }
                        ?>
                        <tr>
                            <td><input type="checkbox" name="facilities[]" disabled="" <?php echo $tv_room; ?> value="tv_room" id="fc1"><label for="fc1" style="display:inline;font-weight:<?php if ($tv_room == "checked") echo "bold"; ?>"> TV | Room</label></td>
                            <td><input type="checkbox" name="facilities[]" disabled="" <?php echo $bed_locker; ?> value="bed_locker" id="fc2"><label for="fc2" style="display:inline;font-weight:<?php if ($bed_locker == "checked") echo "bold"; ?>"> Bed & Locker</label></td>
                            <td><input type="checkbox" name="facilities[]" disabled="" <?php echo $gyeser; ?> value="gyeser" id="fc3"><label for="fc3" style="display:inline;font-weight:<?php if ($gyeser == "checked") echo "bold"; ?>"> Gyeser</label></td>
                        </tr>
                        <?php
                        if (strchr($hostel["facilities"], "water_cooler") != "") {
                            $water_cooler = "checked";
                        }
                        if (strchr($hostel["facilities"], "security") != "") {
                            $security = "checked";
                        }
                        if (strchr($hostel["facilities"], "power_backup") != "") {
                            $power_backup = "checked";
                        }
                        ?>
                        <tr>
                            <td><input type="checkbox" name="facilities[]" disabled="" <?php echo $water_cooler; ?> value="water_cooler" id="fc4"><label for="fc4" style="display:inline;font-weight:<?php if ($water_cooler == "checked") echo "bold"; ?>"> Water Cooler</label></td>
                            <td><input type="checkbox" name="facilities[]" disabled="" <?php echo $security; ?> value="security"  id="fc5"><label for="fc5" style="display:inline;font-weight:<?php if ($security == "checked") echo "bold"; ?>"> Security</label></td>
                            <td><input type="checkbox" name="facilities[]" disabled="" <?php echo $power_backup; ?> value="power_backup" id="fc6"><label for="fc6" style="display:inline;font-weight:<?php if ($power_backup == "checked") echo "bold"; ?>"> Power Backup</label></td>
                        </tr>
                        <?php
                        if (strchr($hostel["facilities"], "parking") != "") {
                            $parking = "checked";
                        }
                        if (strchr($hostel["facilities"], "24_water") != "") {
                            $water_24 = "checked";
                        }
                        if (strchr($hostel["facilities"], "housekeeping") != "") {
                            $housekeeping = "checked";
                        }
                        ?>
                        <tr>
                            <td><input type="checkbox" name="facilities[]" disabled="" <?php echo $parking; ?> value="parking" id="fc7"><label for="fc7" style="display:inline;font-weight:<?php if ($parking == "checked") echo "bold"; ?>"> Parking</label></td>
                            <td><input type="checkbox" name="facilities[]" disabled="" <?php echo $water_24; ?> value="24_water" id="fc8"><label for="fc8" style="display:inline;font-weight:<?php if ($water_24 == "checked") echo "bold"; ?>"> 24×7 water Supply</label></td>
                            <td><input type="checkbox" name="facilities[]" disabled="" <?php echo $housekeeping; ?> value="housekeeping" id="fc9"><label for="fc9" style="display:inline;font-weight:<?php if ($housekeeping == "checked") echo "bold"; ?>"> Housekeeping</label></td>
                        </tr>
                        <?php
                        if (strchr($hostel["facilities"], "ac") != "") {
                            $ac = "checked";
                        }
                        if (strchr($hostel["facilities"], "cc_camera") != "") {
                            $cc_camera = "checked";
                        }
                        if (strchr($hostel["facilities"], "laundry") != "") {
                            $laundry = "checked";
                        }
                        ?>
                        <tr>
                            <td><input type="checkbox" name="facilities[]" disabled="" <?php echo $ac; ?> value="ac" id="fc10"><label for="fc10" style="display:inline;font-weight:<?php if ($ac == "checked") echo "bold"; ?>"> AC</label></td>
                            <td><input type="checkbox" name="facilities[]" disabled="" <?php echo $cc_camera; ?> value="cc_camera" id="fc11"><label for="fc11" style="display:inline;font-weight:<?php if ($cc_camera == "checked") echo "bold"; ?>"> CCTV camera</label></td>
                            <td><input type="checkbox" name="facilities[]" disabled="" <?php echo $laundry; ?> value="laundry" id="fc12"><label for="fc12" style="display:inline;font-weight:<?php if ($laundry == "checked") echo "bold"; ?>">Laundry</label></td>
                        </tr>
                        <?php
                        if (strchr($hostel["facilities"], "kitchen") != "") {
                            $kitchen = "checked";
                        }
                        if (strchr($hostel["facilities"], "table_chair") != "") {
                            $table_chair = "checked";
                        }
                        if (strchr($hostel["facilities"], "refrigenerator") != "") {
                            $refrigenerator = "checked";
                        }
                        ?>
                        <tr>
                            <td><input type="checkbox" name="facilities[]" disabled="" <?php echo $kitchen; ?> value="kitchen" id="fc13"><label for="fc13" style="display:inline;font-weight:<?php if ($kitchen == "checked") echo "bold"; ?>"> Kitchen</label></td>
                            <td><input type="checkbox" name="facilities[]" disabled="" <?php echo $table_chair; ?> value="table_chair" id="fc14"><label for="fc14" style="display:inline;font-weight:<?php if ($table_chair == "checked") echo "bold"; ?>"> Table | Chair</label></td>
                            <td><input type="checkbox" name="facilities[]" disabled="" <?php echo $refrigenerator; ?> value="refrigenerator" id="fc15"><label for="fc15" style="display:inline;font-weight:<?php if ($refrigenerator == "checked") echo "bold"; ?>"> Refrigerator</label></td>
                        </tr>
                        <?php
                        if (strchr($hostel["facilities"], "wifi") != "") {
                            $wifi = "checked";
                        }
                        ?>
                        <tr>
                            <td colspan="3"><input type="checkbox" name="facilities[]" disabled="" <?php echo $wifi; ?> value="wifi" id="fc1"><label for="fc1" style="display:inline;font-weight:<?php if ($wifi == "checked") echo "bold"; ?>"> Wifi</label></td>
                        </tr>
                    </table>




                </div>
                <div class="col-md-6">
                    <h3>House Rules</h3>
                    <hr/>
                    <table width="100%">
                        <?php
                        if (strchr($hostel["house_rule"], "guardian_entry") != "") {
                            $guardian_entry = "checked";
                        }
                        if (strchr($hostel["house_rule"], "girl_entry") != "") {
                            $girl_entry = "checked";
                        }
                        if (strchr($hostel["house_rule"], "non_veg") != "") {
                            $non_veg = "checked";
                        }
                        ?>
                        <tr>
                            <td><input type="checkbox" name="house_rule[]" disabled="" <?php echo $guardian_entry; ?> value="guardian_entry" id="hr1"><label for="hr1" style="display:inline;font-weight:<?php if ($guardian_entry == "checked") echo "bold"; ?>"> Guardian Entry</label></td>
                            <td><input type="checkbox" name="house_rule[]" disabled="" <?php echo $girl_entry; ?> value="girl_entry" id="hr2"><label for="hr2" style="display:inline;font-weight:<?php if ($girl_entry == "checked") echo "bold"; ?>"> Girls Entry</label></td>
                            <td><input type="checkbox" name="house_rule[]" disabled="" <?php echo $non_veg; ?> value="non_veg" id="hr3"><label for="hr3" style="display:inline;font-weight: <?php if ($non_veg == "checked") echo "bold"; ?>"> Non Veg</label></td>
                        </tr>
                        <?php
                        if (strchr($hostel["house_rule"], "drinking") != "") {
                            $drinking = "checked";
                        }
                        if (strchr($hostel["house_rule"], "smoking") != "") {
                            $smoking = "checked";
                        }
                        if (strchr($hostel["house_rule"], "boy_entry") != "") {
                            $boy_entry = "checked";
                        }
                        ?>
                        <tr>
                            <td><input type="checkbox" name="house_rule[]" disabled="" <?php echo $drinking; ?> value="drinking" id="hr4"><label for="hr4" style="display:inline;font-weight:<?php if ($drinking == "checked") echo "bold"; ?>"> Drinking</label></td>
                            <td><input type="checkbox" name="house_rule[]" disabled="" <?php echo $smoking; ?> value="smoking" id="hr5"><label for="hr5" style="display:inline;font-weight:<?php if ($smoking == "checked") echo "bold"; ?>"> Smoking</label></td>
                            <td><input type="checkbox" name="house_rule[]" disabled="" <?php echo $boy_entry; ?> value="boy_entry" id="hr6"><label for="hr6" style="display:inline;font-weight: <?php if ($boy_entry == "checked") echo "bold"; ?>"> Boys Entry</label></td>
                        </tr>
                        <?php
                        if (strchr($hostel["house_rule"], "entry_9pm") != "") {
                            $entry_9pm = "checked";
                        }
                        if (strchr($hostel["house_rule"], "entry_10pm") != "") {
                            $entry_10pm = "checked";
                        }
                        if (strchr($hostel["house_rule"], "entry_11pm") != "") {
                            $entry_11pm = "checked";
                        }
                        ?>
                        <tr>
                            <td><input type="checkbox" name="house_rule[]" disabled="" <?php echo $entry_9pm; ?> value="entry_9pm" id="hr7"><label for="hr7" style="display:inline;font-weight:<?php if ($entry_9pm == "checked") echo "bold"; ?>"> Entry Till 9PM</label></td>
                            <td><input type="checkbox" name="house_rule[]" disabled="" <?php echo $entry_10pm; ?> value="entry_10pm" id="hr8"><label for="hr8" style="display:inline;font-weight: <?php if ($entry_10pm == "checked") echo "bold"; ?>"> Entry Till 10PM</label></td>
                            <td><input type="checkbox" name="house_rule[]" disabled="" <?php echo $entry_11pm; ?> value="entry_11pm" id="hr9"><label for="hr9" style="display:inline;font-weight:<?php if ($entry_11pm == "checked") echo "bold"; ?>"> Entry Till 11PM</label></td>
                        </tr>
                    </table>
                </div>
                <br clear="all"/><br clear="all"/>
                <div class="col-md-6">

                    <h3>Food Type</h3>
                    <hr/>
                    <?php
                    if (strchr($hostel["food_type"], "veg") != "") {
                        $vg = "checked";
                    }
                    if (strchr($hostel["food_type"], "non_veg") != "") {
                        $nvg = "checked";
                    }
                    ?>
                    <input type="checkbox" name="food_type[]" disabled="" <?php echo $vg; ?>  value="veg" id="food_veg" > <label for="food_veg" style="display:inline;font-weight:<?php if ($vg == "checked") echo "bold"; ?>">Veg </label>&nbsp;&nbsp;&nbsp;
                    <input type="checkbox" name="food_type[]" disabled="" <?php echo $nvg; ?>  value="non_veg" id="food_nonveg"> <label for="food_nonveg" style="display:inline;font-weight:<?php if ($nvg == "checked") echo "bold"; ?>">Non - Veg </label>


                </div>
                <div class="col-md-6">

                    <h3>Meals</h3>
                    <hr/>          
                    <?php
                    if (strchr($hostel["meals"], "breakfast") != "") {
                        $breakfast = "checked";
                    }
                    if (strchr($hostel["meals"], "lunch") != "") {
                        $lunch = "checked";
                    }
                    if (strchr($hostel["meals"], "dinner") != "") {
                        $dinner = "checked";
                    }
                    if (strchr($hostel["meals"], "tea") != "") {
                        $tea = "checked";
                    }
                    if (strchr($hostel["meals"], "special") != "") {
                        $special = "checked";
                    }
                    ?>
                    <input type="checkbox" name="meals[]" <?php echo $breakfast; ?> value="breakfast" disabled="" id="meals_breakfast" > <label for="meals_breakfast" style="display:inline;font-weight:<?php if ($breakfast == "checked") echo "bold"; ?>">Breakfast </label>&nbsp;&nbsp;&nbsp;
                    <input type="checkbox" name="meals[]" <?php echo $lunch; ?> value="lunch" disabled="" id="meals_lunch"><label for="meals_lunch" style="display:inline;font-weight:<?php if ($lunch == "checked") echo "bold"; ?> ">Lunch</label>&nbsp;&nbsp;&nbsp;
                    <input type="checkbox" name="meals[]" <?php echo $dinner; ?> value="dinner" disabled="" id="meals_dinner" > <label for="meals_dinner" style="display:inline;font-weight:<?php if ($dinner == "checked") echo "bold"; ?>;">Dinner </label>&nbsp;&nbsp;&nbsp;
                    <input type="checkbox" name="meals[]" <?php echo $tea; ?> value="tea" disabled="" id="meals_tea"> <label for="meals_tea" style="display:inline;font-weight:<?php if ($tea == "checked") echo "bold"; ?>">Tea</label>&nbsp;&nbsp;&nbsp;<br/>
                    <input type="checkbox" name="meals[]" <?php echo $special; ?> value="special" disabled="" id="special"> <label for="special" style="display:inline;font-weight:<?php if ($special == "checked") echo "bold"; ?>">Special</label>&nbsp;&nbsp;&nbsp;
                    <br clear="all"/><br clear="all"/>



                </div>
                <br clear="all"/><br clear="all"/>

            </div>

            <div class="col-md-3">
                <div style="border:1px grey solid;border-radius:10px;padding:10px;">
                    <h4 align="center">Owner Details</h4>
                    <table class="table table-hover" style="text-transform:capitalize;">
                        <tr>
                            <td>Owner Name : <?php echo $hostel["owner_name"]; ?></td> 
                        </tr>                
                        <tr>
                            <td>Property Name : <?php echo $hostel["property_name"]; ?></td> 
                        </tr>
                        <tr>
                            <td>Address : <?php echo $hostel["location"]; ?></td> 
                        </tr>                 
                        <tr>
                            <td>Contact No : <?php echo $hostel["mobile_no"]; ?></td> 
                        </tr>                   
                    </table>
                </div>
                <br clear="left"/>
                <a href="<?php echo base_url(); ?>home/book_now?h_id=<?php echo $hostel["id"]; ?>" class="btn btn-primary">Book Now</a>



            </div>
            <style>
                body{width:610;}
                .demo-table
                {
                    float:left;
                }
                .demo-table th {background: #32C2DB;padding: 5px;text-align: left;color:#FFF;}

                .demo-table td div.feed_title{text-decoration: none;color:#00d4ff;font-weight:bold;}
                .demo-table ul{float:left;list-style-type:none;padding:0px;}
                .demo-table li{cursor:pointer;list-style-type:none;display: inline-block;color: #F0F0F0;text-shadow: 0 0 1px #666666;font-size:20px;}
                .demo-table .highlight, .demo-table .selected {color:#F4B30A;text-shadow: 0 0 1px #F48F0A;}
            </style>
            <div class="col-md-4" style='margin-left:20px;height:350px;'>
                <h3 style="text-transform:capitalize"><?php echo $hostel["occupancy"];?></h3>
                <hr/>
                <?php
                if ($hostel["occupancy"] != "single") {
                    ?>

                    <table width="100%" class="table table-bordered">
                        <tr>
                            <th>Sharing</th>
                            <th>Room Rent</th>
                            <th>Room Security</th>
                        </tr>
                        <?php
//                        echo "<tr><td>1 Peope Sharing</td><td>Rs." . $hostel["room_rent"] . "</td><td>Rs." . $hostel["room_security"] . "</td></tr>";

                        $room_rents = explode("#", $hostel["room_rent1"]);
                        $room_security = explode("#", $hostel["room_security1"]);
                        for ($i = 0; $i < count($room_rents); $i++) {
                            if ($room_rents[$i] != 0) {
                                echo "<tr><td>" . ($i + 2) . " Peope Sharing</td><td>Rs." . $room_rents[$i] . "</td><td>Rs." . $room_security[$i] . "</td></tr>";
                            }
                        }
                        ?>
                    </table>

                    <?php
                } else {
                    ?>
                    <table width="100%" class="table table-bordered">
                        <tr>
                            <th>Sharing</th>
                            <th>Room Rent</th>
                            <th>Room Security</th>
                        </tr>
                        <?php
                        echo "<tr><td>1 Peope Sharing</td><td>Rs." . $hostel["room_rent"] . "</td><td>Rs." . $hostel["room_security"] . "</td></tr>";
                        echo "</table>";
                    }
                    ?>
            </div>
            <div class="col-md-5">
                <h3>&nbsp;&nbsp;&nbsp;&nbsp;Video</h3>
                <hr/>
                <iframe width="100%" style="height:330px;" src="<?php echo $hostel["youtube_link"]; ?>"></iframe>
            </div>
            
            <br clear="all"/>            <br clear="all"/>            <br clear="all"/>
                        <br clear="all"/>
                                    <br clear="all"/>            <br clear="all"/>
            <div class="col-md-4">
                <h4 align="center">Review & Rating</h4>
                <form action="<?php echo base_url(); ?>home/review_action" method="post"/>
                <table width="100%">
                    <tr>
                        <td>Title</td>
                        <td>
                            <div class="form-group">
                                <input type="text" name="review_title" class="form-control" required=""/>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td>Review</td>
                        <td>
                            <div class="form-group">
                                <input type="text" name="review_description" class="form-control" required=""/>
                            </div>
                        </td>
                    </tr>
                    <script src="<?php echo base_url(); ?>includes/js/jquery.js"></script>
                    <script type="text/javascript">
                    $(document).ready(function() {
                        $(".rating_btn").click(function() {
                            var m = $(this).attr("rel");
                            for (j = 1; j <= 5; j++)
                            {
                                $(".rating" + j).removeClass("selected");
                            }
                            for (i = 1; i <= m; i++)
                            {
                                $(".rating" + i).addClass("selected");
                                $("#rating").val(m);
                            }

                        });
                    });
                    </script>
                    <tr>
                        <td>Rating</td>
                        <td>
                            <div class="form-group">
                                <input type="hidden" name="rating" id="rating" value="0" class="form-control">
                                <table class="demo-table" align="center">
                                    <td>
                                        <ul>
                                            <li class="rating1 rating_btn" rel="1">&#9733;</li>
                                            <li class="rating2 rating_btn" rel="2">&#9733;</li>
                                            <li class="rating3 rating_btn" rel="3">&#9733;</li>
                                            <li class="rating4 rating_btn" rel="4">&#9733;</li>
                                            <li class="rating5 rating_btn" rel="5">&#9733;</li>
                                        </ul>
                                    </td>
                                </table>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td>Name</td>
                        <td>
                            <div class="form-group">
                                <input type="text" name="user_name" required="" class="form-control">
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td>Email ID</td>
                        <td>
                            <div class="form-group">
                                <input type="email" name="email" required="" class="form-control">
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td>Contact</td>
                        <td>
                            <div class="form-group">
                                <input type="text" name="contact" required="" class="form-control">
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="2"><input type="submit" name="submit" value="submit" class="btn btn-primary"></td>
                    </tr>

                </table>
                <input type="hidden" name="hostel_id" value="<?php echo $_GET["id"]; ?>"/>
                </form>
            </div>
            <div class="col-md-5">
                <h4 align="center">Feedback</h4>
                <form action="<?php echo base_url(); ?>home/feedback_action" method="post"/>
                <table width="100%">
                    <tr>
                        <td>Name</td>
                        <td>
                            <div class="form-group">
                                <input type="text" name="name" class="form-control" required=""/>
                            </div>
                        </td>
                    </tr>

                    <tr>
                        <td>Email ID</td>
                        <td>
                            <div class="form-group">
                                <input type="email" name="email" required="" class="form-control">
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td>Contact</td>
                        <td>
                            <div class="form-group">
                                <input type="text" name="contact" required="" class="form-control">
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td>Feedback Category</td>
                        <td>
                            <div class="form-group">
                                <select name="feedback_category" class="form-control">
                                    <option value="0">Select Category</option>
                                    <option>Address Details are Wrong.</option>
                                    <option>Facilities Details are Wrong.</option>
                                    <option>Pricing Details are Wrong.</option>
                                    <option>Business Closed.</option>
                                    <option>Other</option>
                                </select>
                            </div>
                        </td>
                    </tr>


                    <tr>
                        <td>Message</td>
                        <td>
                            <div class="form-group">
                                <textarea rows="4" name="message" style="width:100%;">
                                    
                                </textarea>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="2"><input type="submit" name="submit" value="submit" class="btn btn-primary"></td>
                    </tr>

                </table>
                <input type="hidden" name="hostel_id" value="<?php echo $_GET["id"]; ?>"/>
                </form>
            </div>

        </div>
                <style>
            body{width:610;}
            .demo-table
            {
                float:left;
            }
            .demo-table th {background: #32C2DB;padding: 5px;text-align: left;color:#FFF;}

            .demo-table td div.feed_title{text-decoration: none;color:#00d4ff;font-weight:bold;}
            .demo-table ul{float:left;list-style-type:none;padding:0px;}
            .demo-table li{cursor:pointer;list-style-type:none;display: inline-block;color: #F0F0F0;text-shadow: 0 0 1px #666666;font-size:20px;}
            .demo-table .highlight, .demo-table .selected {color:#F4B30A;text-shadow: 0 0 1px #F48F0A;}
        </style>
        <div class="col-md-12">
            <h4>Reviews</h4>
            <hr/>
            <?php
            foreach($reviews as $review)
            {
                ?>
            <div class="col-md-6" style="border:1px #F4F4F4 solid;padding:10px;border-radius:10px;margin:10px;box-shadow:0px 0px 2px #F4F4F4">
                <div class="col-md-3">
                    <img src="<?php echo base_url();?>includes/img/Headshot-Blank-Person-Circle.gif" height="105px" class="img-circle"/>
                    <br/>
                    <p align="center" style="text-transform:capitalize"><?php echo $review["user_name"];?></p>
                </div>
                <div class="col-md-9">
                    <b style="text-transform:capitalize;"><?php echo $review["review_title"];?></b>
                    <hr/>
                    <?php echo $review["review_description"];?>
                    <br clear="all"/>
                    <label style="float:left;">Rating:</label>
                    <table class="demo-table" align="center">
                                            <td>
                                                <ul>
                                                    <?php
                                                    for ($i = 1; $i <= 5; $i++) {
                                                        if ($i <= $review["rating"]) {
                                                            ?>
                                                            <li class="selected">&#9733;</li>
                                                            <?php
                                                        } else {
                                                            ?>
                                                            <li>&#9733;</li>
                                                            <?php
                                                        }
                                                    }
                                                    ?>

                                                </ul>
                                            </td>
                                        </table>
                </div>
            </div>
            <br clear="all"/>
            <?php
            }
            ?>
        </div>
    </div>
    <style>
        .fluid-width-video-wrapper
        {
            padding-top:0px !important;
        }
    </style>
    <div class="gap gap-small"></div>
</div>




