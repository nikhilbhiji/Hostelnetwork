
<footer id="main-footer">
    <div class="container">
        <div class="row row-wrap">
            <div class="col-md-3">
                <a class="logo" href="<?php echo base_url(); ?>">
                    Hostel Network
                </a>
                <p class="mb20">Hostel booking online!</p>
                <ul class="list list-horizontal list-space">
                    <li>
                        <a class="fa fa-facebook box-icon-normal round animate-icon-bottom-to-top" href="https://www.facebook.com/www.hostelnetwork.in/?fref=ts"></a>
                    </li>
                    <li>
                        <a class="fa fa-twitter box-icon-normal round animate-icon-bottom-to-top" href="index.html#"></a>
                    </li>
                    <li>
                        <a class="fa fa-google-plus box-icon-normal round animate-icon-bottom-to-top" href="index.html#"></a>
                    </li>
                    <li>
                        <a class="fa fa-linkedin box-icon-normal round animate-icon-bottom-to-top" href="index.html#"></a>
                    </li>
                    <li>
                        <a class="fa fa-pinterest box-icon-normal round animate-icon-bottom-to-top" href="index.html#"></a>
                    </li>
                </ul>
            </div>

            <div class="col-md-3">
                <h4>Facebook Like Box</h4>
                <div class="centered service"><div class="centered">
                        <script type="text/javascript" src="http://www.chromeactions.com/js/3dlikebox.js"></script>
                        <style>
                            iframe{background:white;}
                        </style>
                        <div class="likebox3d"
                             data-url="https://www.facebook.com/www.hostelnetwork.in/?fref=ts"
                             data-auto
                             data-depth="800"
                             data-origin="left bottom"
                             data-direction="1,1,0"
                             data-duration="2"
                             data-delay="5"
                             style="width:250px;height:300px;background:white;">
                        </div></div>
                </div>
            </div>
            <div class="col-md-2">
                <h4>Pages</h4>
                <ul class="list list-footer">
                    <li><a href="<?php echo base_url(); ?>home">Home</a>
                    </li>
                    <li><a href="<?php echo base_url(); ?>home/aboutus">About Us</a>
                    </li>
                    <li><a href="<?php echo base_url(); ?>home/privacy_policy">Privacy Policy</a>
                    </li>

                    <li><a href="<?php echo base_url(); ?>home/term_condition">Terms & Conditions</a>
                    </li>
                </ul>
            </div>
            <div class="col-md-4">
                <h4>Contact Us</h4>
                <h4 class="text-color">+91-9479421082</h4>
                <h4 class="text-color">+91-9138100676</h4>
                
                <p>(10AM-7PM)</p>
                <p>(Monday - Saturday)</p>

                <p>info@hostelnetwork.in</p>
            </div>
            <div class="col-md-12">
                <p align="center">Designed & Developed by : <b><a href="http://www.webtekworld.com">WEBTEKWORLD</a></b></p>
            </div>
        </div>
    </div>
</footer>

<script src="<?php echo base_url(); ?>includes/js/jquery.js"></script>
<script src="<?php echo base_url(); ?>includes/js/bootstrap.js"></script>
<script src="<?php echo base_url(); ?>includes/js/slimmenu.js"></script>
<script src="<?php echo base_url(); ?>includes/js/bootstrap-datepicker.js"></script>
<script src="<?php echo base_url(); ?>includes/js/bootstrap-timepicker.js"></script>
<script src="<?php echo base_url(); ?>includes/js/nicescroll.js"></script>
<script src="<?php echo base_url(); ?>includes/js/dropit.js"></script>
<script src="<?php echo base_url(); ?>includes/js/ionrangeslider.js"></script>
<script src="<?php echo base_url(); ?>includes/js/icheck.js"></script>
<script src="<?php echo base_url(); ?>includes/js/fotorama.js"></script>

<script src="<?php echo base_url(); ?>includes/js/typeahead.js"></script>
<script src="<?php echo base_url(); ?>includes/js/card-payment.js"></script>
<script src="<?php echo base_url(); ?>includes/js/magnific.js"></script>
<script src="<?php echo base_url(); ?>includes/js/owl-carousel.js"></script>
<script src="<?php echo base_url(); ?>includes/js/fitvids.js"></script>
<script src="<?php echo base_url(); ?>includes/js/tweet.js"></script>
<script src="<?php echo base_url(); ?>includes/js/countdown.js"></script>
<script src="<?php echo base_url(); ?>includes/js/gridrotator.js"></script>
<script src="<?php echo base_url(); ?>includes/js/custom.js"></script>
<script src="<?php echo base_url(); ?>includes/js/switcher.js"></script>
</div>
</body>

</html>



