

<br clear="all"/>
<style>
    li.list1
    {
        list-style-type:none;
    }
</style>
<div class="container">
    <div class="row " >   
        <div class="col-md-12">
            <div class="col-md-12">                
                <?php
                if ($this->session->flashdata('signup')) {
                    echo "<div class='alert alert-success'><i class='entypo-check'></i> " .
                    $this->session->flashdata('signup') .
                    "</div>";
                }
                if ($this->session->flashdata('notify')) {
                    echo "<div class='alert alert-danger'><i class='entypo-check'></i> " .
                    $this->session->flashdata('notify') .
                    "</div>";
                }
                ?>
            </div>
            <form action="<?php echo base_url(); ?>home/login_action" method="post">
                <h3 class="mb15">All Cities</h3>
                <div class="col-md-12">   


                    <?php
                    $i = 0;
                    $j = 0;
                    $flag = 0;
                    $k = 0;
                    $w = 0;

//                    $alphabet = Array('a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z');
                    $alphabet = 'a';
                    echo "<h1 style='text-transform:uppercase;'>" . $alphabet . "</h1>";
                    $h = 1;
                    foreach ($cities as $city) {
                        if ($i == 0) {
//                                    echo "<div class='col-md-3'>";
                            $flag = 1;
                        }
                        if ($flag == 1) {
                            $j++;
                        }
                        if (strtolower($city["city_name"][0]) == $alphabet) {
                            $w++;
                        } else {
                            $w = 0;
                            $alphabet = strtolower($city["city_name"][0]);
                        }

                        if ($w == 0) {
                            echo "<h1 style='text-transform:uppercase;'>" . $alphabet . "</h1>";
                        }


                        echo "<li class='list1'><a href='" . base_url() . "home/search?location=" . $city["city_name"] . "'>" . strtoupper($city["city_name"]) . "</a></li>";

                        $i++;
                        if ($j == 1) {
  //                              echo "</div>";
                            $h++;
                            if ($h == 4) {
                                //  echo "<br clear=all>";
                                $h = 0;
                            }
                            $j = 0;
                            $i = 0;
                        }
                    }
                    ?>
                </div>
        </div>

        </form>                                  
    </div>

</div>
<div class="gap gap-small"></div>
</div>




