

<br clear="all"/>

<div class="container">
    <div class="row " >   
        <div class="col-md-12">
            <div class="col-md-12">                
                <?php
                if ($this->session->flashdata('signup')) {
                    echo "<div class='alert alert-success'><i class='entypo-check'></i> " .
                    $this->session->flashdata('signup') .
                    "</div>";
                }
                if ($this->session->flashdata('notify')) {
                    echo "<div class='alert alert-danger'><i class='entypo-check'></i> " .
                    $this->session->flashdata('notify') .
                    "</div>";
                }
                ?>
            </div>
            <form action="<?php echo base_url();?>home/booking_action" method="post">
                <div class="col-md-6">   
                    <h3 class="mb15">Booking Confirmation</h3>
                    <hr/>
                    
                    <p>Note : When you call, please mention that you get details from Hostelnetwork website.</p>
                    <p>If you like our service. Please Like & Share our Page. </p>
                                    <div class="centered service"><div class="centered">
                        <script type="text/javascript" src="http://www.chromeactions.com/js/3dlikebox.js"></script>
                        <style>
                            iframe{background:white;}
                        </style>
                        <div class="likebox3d"
                             data-url="https://www.facebook.com/www.hostelnetwork.in/?fref=ts"
                             data-auto
                             data-depth="800"
                             data-origin="left bottom"
                             data-direction="1,1,0"
                             data-duration="2"
                             data-delay="5"
                             style="width:100%;height:300px;background:white;">
                        </div></div>
                </div>
                </div>

            </form>                                  
        </div>

    </div>
    <div class="gap gap-small"></div>
</div>




