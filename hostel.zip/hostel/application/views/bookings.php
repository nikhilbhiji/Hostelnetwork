

<br clear="all"/>

<div class="container">
    <div class="row " >   
        <div class="col-md-12">
            <div class="col-md-12">                
                <?php
                if ($this->session->flashdata('notify')) {
                    echo "<div class='alert alert-danger'><i class='entypo-check'></i> " .
                    $this->session->flashdata('notify') .
                    "</div>";
                }
                 if ($this->session->flashdata('booking_delete')) {
                    echo "<div class='alert alert-danger'><i class='entypo-check'></i> " .
                    $this->session->flashdata('booking_delete') .
                    "</div>";
                }
                ?>
            </div>
            <h3 align="center">Bookings</h3>
            <table class="table table-bordered table-hover">             
                <tr>
                    <th>#</th>
                    <th>Name</th>
                    <th>Mobile No</th>
                    <th>Email</th>
                    <th>Action</th>
                </tr>
                <?php
                $i=1;
                foreach($bookings as $booking)
                {
                 ?>
                <tr>
                    <td><?php echo $i;?></td>
                    <td><?php echo $booking["name"];?></td>
                    <td><?php echo $booking["mobile_no"]?></td>
                    <td><?php echo $booking["email"]?></td>
                    <td><a href="<?php echo base_url()?>home/delete_booking?bid=<?php echo $booking["id"]?>" class="btn btn-danger">Delete</a></td>
                </tr>
                <?php
                }                
                ?>
            </table>
        </div>

    </div>
    <div class="gap gap-small"></div>
</div>




