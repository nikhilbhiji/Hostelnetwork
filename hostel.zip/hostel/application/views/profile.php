<?php
//set for undefined variables
error_reporting(0);
?>
<br clear="all"/>

<div class="container">
    <div class="row " >   
        <div class="col-md-12">                
            <?php
            if ($this->session->flashdata('profile')) {
                echo "<div class='alert alert-success'><i class='entypo-check'></i> " .
                $this->session->flashdata('profile') .
                "</div>";
            }
            if ($this->session->flashdata('notify')) {
                echo "<div class='alert alert-danger'><i class='entypo-check'></i> " .
                $this->session->flashdata('notify') .
                "</div>";
            }
            ?>
        </div>
        <div class="col-md-12">
            <h3 class="mb15" align="center">Profile</h3>
            <form action="<?php echo base_url() ?>home/profile_action" method="post" enctype="multipart/form-data">
                <div class="col-md-4">   
                    <h5>Property Information</h5>
                    <hr/>
                    <div class="form-group ">
                        <label>Property For</label>
                        <input type="radio" name="property_for" <?php if ($hostel["property_for"] == "male") echo "checked"; ?> value="male" id="male" > <label for="male" style="display:inline;">Male </label>&nbsp;&nbsp;&nbsp;
                        <input type="radio" name="property_for" <?php if ($hostel["property_for"] == "female") echo "checked"; ?> value="female" id="female"> <label for="female" style="display:inline">Female </label>
                    </div>
                    <div class="form-group ">
                        <label>Property Type</label>
                        <input type="radio" name="property_type" <?php if ($hostel["property_type"] == "hostel") echo "checked"; ?> value="hostel" id="hostel_type" > <label for="hostel_type" style="display:inline;">Hostel </label>&nbsp;&nbsp;&nbsp;
                        <input type="radio" name="property_type" <?php if ($hostel["property_type"] == "pg") echo "checked"; ?> value="pg" id="pg_type"> <label for="pg_type" style="display:inline">P.G</label>&nbsp;&nbsp;&nbsp;
                        <input type="radio" name="property_type" <?php if ($hostel["property_type"] == "room") echo "checked"; ?> value="room" id="room_type"> <label for="room_type" style="display:inline">Room</label>
                    </div>
                     <script type="text/javascript">
                        function check_sharing()
                        {

                            if (document.getElementById("single").checked == true)
                            {
                                $(document).ready(function() {
                                    $(".rt_class").attr("disabled", true);                                    
                                    $("#room_security").attr("disabled", false);
                                    $("#room_rent").attr("disabled", false);
                                });
                            }
                            if (document.getElementById("single").checked == false)
                            {
                                $(document).ready(function() {
                                    $(".rt_class").attr("disabled", false);
                                    $("#room_security").attr("disabled", true);
                                    $("#room_rent").attr("disabled", true);
                                });
                            }
                        }
           
<?php
if ($hostel["occupancy"] == "single") {
    ?>
                            $(document).ready(function() {
                                $(".rt_class").attr("disabled", false);
                            });
    <?php
}
?>
                    </script>
                    <div class="form-group ">
                        <label>Occupancy</label>
                        <input type="radio" name="occupancy" value="single" <?php if ($hostel["occupancy"] == "single") echo "checked"; ?> onclick="check_sharing()" id="single" > <label for="single" style="display:inline;">Single Room </label>&nbsp;&nbsp;&nbsp;
                        <input type="radio" name="occupancy" value="sharing" <?php if ($hostel["occupancy"] == "sharing") echo "checked"; ?> onclick="check_sharing()" id="sharing"> <label for="sharing" style="display:inline">Sharing Rooms </label>
                    </div>
                    <div class="form-group ">                       
                        <input type="text" placeholder="Property Name" value="<?php echo $hostel["property_name"]; ?>" name="property_name" class="form-control">
                    </div>
                    <div class="form-group ">                       
                        <input type="text" placeholder="Owner Name" value="<?php echo $hostel["owner_name"]; ?>" required="" name="owner_name" class="form-control">
                    </div>
                    <div class="form-group ">                       
                        <input type="text" placeholder="Mobile No" value="<?php echo $hostel["mobile_no"]; ?>" required=""  name="mobile_no" class="form-control">
                    </div>
                    <div class="form-group ">                       
                        <input type="text" placeholder="Phone/Alternate Mobile No" value="<?php echo $hostel["alternate_no"]; ?>" name="alternate_no" class="form-control">
                    </div>                 
                    <div class="form-group ">                       
                        <input type="text" placeholder="House No, Street" value="<?php echo $hostel["house_no"]; ?>" name="house_no" class="form-control">
                    </div>
                    <div class="form-group ">                       
                        <input type="text" placeholder="Landmark" value="<?php echo $hostel["landmark"]; ?>" name="landmark" class="form-control">
                    </div>
                    <div class="form-group">
                        <input id="main_address" name="location" value="<?php echo $hostel["location"]; ?>" class="form-control" placeholder="Location" type="text" />
                    </div>
                    <div class="form-group">
                        <select name="city" class="form-control">
                            <option value="">Select City</option>
                            <?php
                            foreach($cities as $city){
                                if($city["city_name"] == $hostel["city"])
                                    $val = "selected";
                                else
                                    $val = "";
                                echo "<option value='".$city["city_name"]."' $val>".strtoupper($city["city_name"])."</option>";
                            }
                            ?>                            
                        </select>
                    </div>
                    <div class="form-group ">                       
                        <input type="email" placeholder="Email Id" value="<?php echo $hostel["email"]; ?>" required="" name="email" class="form-control">
                    </div>
                    <div class="form-group ">                       
                        <input type="password" placeholder="Password" value="<?php echo base64_decode($hostel["password"]); ?>" required="" name="password" class="form-control">
                    </div>

                    <h5>Food Type</h5>
                    <hr style="margin:0px"/>
                    <div class="form-group">
                        <?php
                        if (strchr($hostel["food_type"], "veg") != "") {
                            $vg = "checked";
                        }
                        if (strchr($hostel["food_type"], "non_veg") != "") {
                            $nvg = "checked";
                        }
                        ?>
                        <input type="checkbox" name="food_type[]" <?php echo $vg; ?>  value="veg" id="food_veg" > <label for="food_veg" style="display:inline;">Veg </label>&nbsp;&nbsp;&nbsp;
                        <input type="checkbox" name="food_type[]" <?php echo $nvg; ?>  value="non_veg" id="food_nonveg"> <label for="food_nonveg" style="display:inline">Non - Veg </label>
                    </div>
                    <h5>Meals</h5>
                    <hr style="margin:0px"/>
                    <div class="form-group">
                        <?php
                        if (strchr($hostel["meals"], "breakfast") != "") {
                            $breakfast = "checked";
                        }
                        if (strchr($hostel["meals"], "lunch") != "") {
                            $lunch = "checked";
                        }
                        if (strchr($hostel["meals"], "dinner") != "") {
                            $dinner = "checked";
                        }
                        if (strchr($hostel["meals"], "tea") != "") {
                            $tea = "checked";
                        }
                        if (strchr($hostel["meals"], "special") != "") {
                            $special = "checked";
                        }
                        ?>
                        <input type="checkbox" name="meals[]" <?php echo $breakfast; ?> value="breakfast" id="meals_breakfast" > <label for="meals_breakfast" style="display:inline;">Breakfast </label>&nbsp;&nbsp;&nbsp;
                        <input type="checkbox" name="meals[]" <?php echo $lunch; ?> value="lunch" id="meals_lunch"> <label for="meals_lunch" style="display:inline">Lunch</label>&nbsp;&nbsp;&nbsp;
                        <input type="checkbox" name="meals[]" <?php echo $dinner; ?> value="dinner" id="meals_dinner" > <label for="meals_dinner" style="display:inline;">Dinner </label>&nbsp;&nbsp;&nbsp;
                        <input type="checkbox" name="meals[]" <?php echo $tea; ?> value="tea" id="meals_tea"> <label for="meals_tea" style="display:inline">Tea</label>&nbsp;&nbsp;&nbsp;<br/>
                        <input type="checkbox" name="meals[]" <?php echo $special; ?> value="special" id="special"> <label for="special" style="display:inline">Special</label>&nbsp;&nbsp;&nbsp;
                    </div>
                    <h5>Upload Property Images</h5>
                    <hr style="margin:0px"/>

                    <div class="col-md-6">
                        <label>Main Building View</label>
                        <img src="<?php echo base_url(); ?>includes/upload/thimg/<?php echo $hostel["img"]; ?>" height="100px" class="img-thumbnail"/>
                        <input type="hidden" name="cur_img" value="<?php echo $hostel["img"]; ?>"/>
                        <div class="form-group ">                       
                            <input type="file" name="img" class="form-control">
                        </div>

                    </div>

                    <div class="col-md-6">    
                        <label>Image 1</label>
                        <img src="<?php echo base_url(); ?>includes/upload/thimg/<?php echo $hostel["img2"]; ?>" height="100px" class="img-thumbnail"/>
                        <input type="hidden" name="cur_img2" value="<?php echo $hostel["img2"]; ?>"/>
                        <div class="form-group ">                       
                            <input type="file" name="img2" class="form-control">
                        </div>

                    </div>
                    <div class="col-md-6">      
                        <label>Image 2</label>
                        <img src="<?php echo base_url(); ?>includes/upload/thimg/<?php echo $hostel["img3"]; ?>" height="100px" class="img-thumbnail"/>
                        <input type="hidden" name="cur_img3" value="<?php echo $hostel["img3"]; ?>"/>
                        <div class="form-group ">                       
                            <input type="file" name="img3" class="form-control">
                        </div>

                    </div>
                    <div class="col-md-6">      
                        <label>Image 3</label>
                        <img src="<?php echo base_url(); ?>includes/upload/thimg/<?php echo $hostel["img4"]; ?>" height="100px" class="img-thumbnail"/>
                        <input type="hidden" name="cur_img4" value="<?php echo $hostel["img4"]; ?>"/>
                        <div class="form-group ">                       
                            <input type="file" name="img4" class="form-control">
                        </div>

                    </div>

                    <div class="col-md-6">      
                        <label>Image 4</label>
                        <img src="<?php echo base_url(); ?>includes/upload/thimg/<?php echo $hostel["img5"]; ?>" height="100px" class="img-thumbnail"/>
                        <input type="hidden" name="cur_img5" value="<?php echo $hostel["img5"]; ?>"/>
                        <div class="form-group ">                       
                            <input type="file" name="img5" class="form-control">
                        </div>

                    </div>

                </div>
                <div class="col-md-4">               
                    <h5>Price Information</h5>
                    <hr/>
                    <h6>Security Deposit</h6>
                    <div class="form-group">
                        <label>Room Detail - Single Occupancy</label>                                                
                        <div class="col-xs-6">               
                            <input type="text" placeholder="Room Rent" required="" id="room_rent" value="<?php echo $hostel["room_rent"]; ?>" name="room_rent" class="form-control">
                        </div>
                        <div class="col-xs-6">               
                            <input type="text" placeholder="Room Security" id="room_security" value="<?php echo $hostel["room_security"]; ?>" required="" name="room_security" class="form-control">
                        </div>                            
                    </div><br clear="all"/><br clear="all"/>
                    <?php
                    $room_rents = explode("#", $hostel["room_rent1"]);
                    $room_security = explode("#", $hostel["room_security1"]);
                    ?>
                    <div class="form-group">
                        <label>Room Detail - 2 People Sharing</label>                        
                        <div class="col-xs-6">               
                            <input type="text" placeholder="Room Rent" value="<?php echo $room_rents[0]; ?>" name="room_rent1[]" class="form-control rt_class">
                        </div>
                        <div class="col-xs-6">               
                            <input type="text" placeholder="Room Security" value="<?php echo $room_security[0]; ?>" name="room_security1[]" class="form-control rt_class">
                        </div>   
                    </div><br clear="all"/><br clear="all"/>
                    <div class="form-group">
                        <label>Room Detail - 3 People Sharing</label>                        
                        <div class="col-xs-6">               
                            <input type="text" placeholder="Room Rent" value="<?php echo $room_rents[1]; ?>" name="room_rent1[]" class="form-control rt_class">
                        </div>
                        <div class="col-xs-6">               
                            <input type="text" placeholder="Room Security" value="<?php echo $room_security[1]; ?>" name="room_security1[]" class="form-control rt_class">
                        </div>   
                    </div><br clear="all"/><br clear="all"/>
                    <div class="form-group">
                        <label>Room Detail - 4 People Sharing</label>                        
                        <div class="col-xs-6">               
                            <input type="text" placeholder="Room Rent" value="<?php echo $room_rents[2]; ?>" name="room_rent1[]" class="form-control rt_class">
                        </div>
                        <div class="col-xs-6">               
                            <input type="text" placeholder="Room Security" value="<?php echo $room_security[2]; ?>" name="room_security1[]" class="form-control rt_class">
                        </div>   
                    </div><br clear="all"/><br clear="all"/>
                    <div class="form-group">
                        <label>Room Detail - 5 People Sharing</label>                        
                        <div class="col-xs-6">               
                            <input type="text" placeholder="Room Rent" value="<?php echo $room_rents[3]; ?>" name="room_rent1[]" class="form-control rt_class">
                        </div>
                        <div class="col-xs-6">               
                            <input type="text" placeholder="Room Security" value="<?php echo $room_security[3]; ?>" name="room_security1[]" class="form-control rt_class">
                        </div>   
                    </div>
                    <br clear="all"/><br clear="all"/>
                    <h5>Facilities</h5>
                    <table width="100%">
                        <?php
                        if (strchr($hostel["facilities"], "tv_room") != "") {
                            $security = "checked";
                        }
                        if (strchr($hostel["facilities"], "bed_locker") != "") {
                            $bed_locker = "checked";
                        }
                        if (strchr($hostel["facilities"], "gyeser") != "") {
                            $gyeser = "checked";
                        }
                        ?>
                        <tr>
                            <td><input type="checkbox" name="facilities[]" <?php echo $security; ?> value="tv_room" id="fc1"><label for="fc1" style="display:inline;"> TV | Room</label></td>
                            <td><input type="checkbox" name="facilities[]" <?php echo $bed_locker; ?> value="bed_locker" id="fc2"><label for="fc2" style="display:inline;"> Bed & Locker</label></td>
                            <td><input type="checkbox" name="facilities[]" <?php echo $gyeser; ?> value="gyeser" id="fc3"><label for="fc3" style="display:inline;"> Gyeser</label></td>
                        </tr>
                        <?php
                        if (strchr($hostel["facilities"], "water_cooler") != "") {
                            $water_cooler = "checked";
                        }
                        if (strchr($hostel["facilities"], "security") != "") {
                            $security = "checked";
                        }
                        if (strchr($hostel["facilities"], "power_backup") != "") {
                            $power_backup = "checked";
                        }
                        ?>
                        <tr>
                            <td><input type="checkbox" name="facilities[]" <?php echo $water_cooler; ?> value="water_cooler" id="fc4"><label for="fc4" style="display:inline;"> Water Cooler</label></td>
                            <td><input type="checkbox" name="facilities[]" <?php echo $security; ?> value="security"  id="fc5"><label for="fc5" style="display:inline;"> Security</label></td>
                            <td><input type="checkbox" name="facilities[]" <?php echo $power_backup; ?> value="power_backup" id="fc6"><label for="fc6" style="display:inline;"> Power Backup</label></td>
                        </tr>
                        <?php
                        if (strchr($hostel["facilities"], "parking") != "") {
                            $parking = "checked";
                        }
                        if (strchr($hostel["facilities"], "24_water") != "") {
                            $water_24 = "checked";
                        }
                        if (strchr($hostel["facilities"], "housekeeping") != "") {
                            $housekeeping = "checked";
                        }
                        ?>
                        <tr>
                            <td><input type="checkbox" name="facilities[]" <?php echo $parking; ?> value="parking" id="fc7"><label for="fc7" style="display:inline;"> Parking</label></td>
                            <td><input type="checkbox" name="facilities[]" <?php echo $water_24; ?> value="24_water" id="fc8"><label for="fc8" style="display:inline;"> 24×7 water Supply</label></td>
                            <td><input type="checkbox" name="facilities[]" <?php echo $housekeeping; ?> value="housekeeping" id="fc9"><label for="fc9" style="display:inline;"> Housekeeping</label></td>
                        </tr>
                        <?php
                        if (strchr($hostel["facilities"], "ac") != "") {
                            $ac = "checked";
                        }
                        if (strchr($hostel["facilities"], "cc_camera") != "") {
                            $cc_camera = "checked";
                        }
                        if (strchr($hostel["facilities"], "laundry") != "") {
                            $laundry = "checked";
                        }
                        ?>
                        <tr>
                            <td><input type="checkbox" name="facilities[]" <?php echo $ac; ?> value="ac" id="fc10"><label for="fc10" style="display:inline;"> AC</label></td>
                            <td><input type="checkbox" name="facilities[]" <?php echo $cc_camera; ?> value="cc_camera" id="fc11"><label for="fc11" style="display:inline;"> CCTV camera</label></td>
                            <td><input type="checkbox" name="facilities[]" <?php echo $laundry; ?> value="laundry" id="fc12"><label for="fc12" style="display:inline;">Laundry</label></td>
                        </tr>
                        <?php
                        if (strchr($hostel["facilities"], "kitchen") != "") {
                            $kitchen = "checked";
                        }
                        if (strchr($hostel["facilities"], "table_chair") != "") {
                            $table_chair = "checked";
                        }
                        if (strchr($hostel["facilities"], "refrigenerator") != "") {
                            $refrigenerator = "checked";
                        }
                        ?>
                        <tr>
                            <td><input type="checkbox" name="facilities[]" <?php echo $kitchen; ?> value="kitchen" id="fc13"><label for="fc13" style="display:inline;"> Kitchen</label></td>
                            <td><input type="checkbox" name="facilities[]" <?php echo $table_chair; ?> value="table_chair" id="fc14"><label for="fc14" style="display:inline;"> Table | Chair</label></td>
                            <td><input type="checkbox" name="facilities[]" <?php echo $refrigenerator; ?> value="refrigenerator" id="fc15"><label for="fc15" style="display:inline;"> Refrigerator</label></td>
                        </tr>
                        <?php
                        if (strchr($hostel["facilities"], "wifi") != "") {
                            $wifi = "checked";
                        }
                        ?>
                        <tr>
                            <td colspan="3"><input type="checkbox" name="facilities[]" <?php echo $wifi; ?> value="wifi" id="fc1"><label for="fc1" style="display:inline;"> Wifi</label></td>
                        </tr>
                    </table>
                    <br clear="all"/>
                    <h5>House Rules</h5>
                    <table width="100%">
                        <?php
                        if (strchr($hostel["house_rule"], "guardian_entry") != "") {
                            $guardian_entry = "checked";
                        }
                        if (strchr($hostel["house_rule"], "girl_entry") != "") {
                            $girl_entry = "checked";
                        }
                        if (strchr($hostel["house_rule"], "non_veg") != "") {
                            $non_veg = "checked";
                        }
                        ?>
                        <tr>
                            <td><input type="checkbox" name="house_rule[]" <?php echo $guardian_entry; ?> value="guardian_entry" id="hr1"><label for="hr1" style="display:inline;"> Guardian Entry</label></td>
                            <td><input type="checkbox" name="house_rule[]" <?php echo $girl_entry; ?> value="girl_entry" id="hr2"><label for="hr2" style="display:inline;"> Girls Entry</label></td>
                            <td><input type="checkbox" name="house_rule[]" <?php echo $non_veg; ?> value="non_veg" id="hr3"><label for="hr3" style="display:inline;"> Non Veg</label></td>
                        </tr>
                        <?php
                        if (strchr($hostel["house_rule"], "drinking") != "") {
                            $drinking = "checked";
                        }
                        if (strchr($hostel["house_rule"], "smoking") != "") {
                            $smoking = "checked";
                        }
                        if (strchr($hostel["house_rule"], "boy_entry") != "") {
                            $boy_entry = "checked";
                        }
                        ?>
                        <tr>
                            <td><input type="checkbox" name="house_rule[]" <?php echo $drinking; ?> value="drinking" id="hr4"><label for="hr4" style="display:inline;"> Drinking</label></td>
                            <td><input type="checkbox" name="house_rule[]" <?php echo $smoking; ?> value="smoking" id="hr5"><label for="hr5" style="display:inline;"> Smoking</label></td>
                            <td><input type="checkbox" name="house_rule[]" <?php echo $boy_entry; ?> value="boy_entry" id="hr6"><label for="hr6" style="display:inline;"> Boys Entry</label></td>
                        </tr>
                        <?php
                        if (strchr($hostel["house_rule"], "entry_9pm") != "") {
                            $entry_9pm = "checked";
                        }
                        if (strchr($hostel["house_rule"], "entry_10pm") != "") {
                            $entry_10pm = "checked";
                        }
                        if (strchr($hostel["house_rule"], "entry_11pm") != "") {
                            $entry_11pm = "checked";
                        }
                        ?>
                        <tr>
                            <td><input type="checkbox" name="house_rule[]" <?php echo $entry_9pm; ?> value="entry_9pm" id="hr7"><label for="hr7" style="display:inline;"> Entry Till 9PM</label></td>
                            <td><input type="checkbox" name="house_rule[]" <?php echo $entry_10pm; ?> value="entry_10pm" id="hr8"><label for="hr8" style="display:inline;"> Entry Till 10PM</label></td>
                            <td><input type="checkbox" name="house_rule[]" <?php echo $entry_11pm; ?> value="entry_11pm" id="hr9"><label for="hr9" style="display:inline;"> Entry Till 11PM</label></td>
                        </tr>
                    </table>
                    <br clear="all"/>
                    <div class="form-group">
                        <label>Enter Youtube Video Url <div style='display:inline;font-size:20px;color:red;'>(Optional)</div></label>
                        <input type="text" name="youtube_link" placeholder="Enter Youtube URL" value="<?php echo $hostel["youtube_link"];?>" class="form-control"/>
                    </div>

                    <br clear="all"/>
                    <center> <input type="submit" value="Update" id="btn_submit" class="btn btn-primary"></center>
                    <div style="form-group">
                        <input id="lat" name="lat" value="<?php echo $hostel["lat"]; ?>" type="hidden" /><br/>
                        <input id="long" name="long" value="<?php echo $hostel["long"]; ?>" type="hidden" /><br/>

                    </div>
                </div>

            </form> 
            <script src="http://maps.google.com/maps/api/js?sensor=false" type="text/javascript"></script>
            <script type='text/javascript'>
                            window.onload = function() {
                                // find DOM elements
                                var latField = document.getElementById('lat');
                                var lngField = document.getElementById('long');
                                var canvas = document.getElementById('map');
                                var form = document.getElementById('addressForm');
                                var addressField = document.getElementById('map_address');
                                // create map, marker, infowindow and geocoder objects
                                var options = {
                                    zoom: 14,
                                    center: new google.maps.LatLng(<?php echo $hostel["lat"] ?>, <?php echo $hostel["long"]; ?>),
                                    mapTypeId: google.maps.MapTypeId.ROADMAP
                                };
                                var map = new google.maps.Map(canvas, options);
                                var marker = new google.maps.Marker({
                                    map: map
                                });
                                var infowindow = new google.maps.InfoWindow();
                                var geocoder = new google.maps.Geocoder();
                                // set handler for form.onsubmit event
                                form.onsubmit = function() {
                                    //   document.getElementById("main_address").value = addressField.value;
                                    return showAddressOnMap(addressField.value);
                                }
                                // worker function to display marker on map at address
                                function showAddressOnMap(address) {
                                    try {
                                        var geocoderRequest = {
                                            address: address
                                        }
                                        geocoder.geocode(geocoderRequest, function(results, status) {
                                            if (status == google.maps.GeocoderStatus.OK) {
                                                var location = results[0].geometry.location;
                                                map.setCenter(location);
                                                marker.setPosition(location);
                                                var content = [];
                                                content.push('<strong>' + results[0].formatted_address + '</strong>');
                                                content.push('Lat: ' + location.lat());
                                                content.push('Lng: ' + location.lng());
                                                infowindow.setContent(content.join('<br/>'));
                                                infowindow.open(map, marker);
                                                latField.value = location.lat();
                                                lngField.value = location.lng();
                                            }
                                        });
                                        return false;
                                    }
                                    catch (e) {
                                        return false;//ensure form does not submit, even if there's an error
                                    }
                                }
                            };
            </script>
            <div class="col-md-4">     
                <h5>Set Your Location</h5>
                <hr/>
                <div class="form-group ">
                    <form id="addressForm" style="margin:10px 0;">
                        <input type="text" required="" value="" placeholder="Search by Area, City, State"   id="map_address" class="form-control">
                        <br clear="all"/>
                        <input type="submit" value="Search" class="btn btn-primary">
                    </form>
                </div>
                <div id="map" style="width:100%;height:350px;border:1px solid #999;"></div>

            </div>




        </div>

    </div>
    <div class="gap gap-small"></div>
</div>




