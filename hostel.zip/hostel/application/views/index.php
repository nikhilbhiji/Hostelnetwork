<!-- TOP AREA -->
<div class="top-area show-onload">
    <div class="bg-holder full">
        <div class="bg-mask"></div>
        <div class="bg-parallax" style="background-image:url(<?php echo base_url(); ?>includes/img/web_03.jpg);"></div>
        <div class="bg-content">
            <div class="container" >
                <div class="row">
                    <div class="col-md-12" style="margin-top:100px;">             
                        <h1 style="color:white;text-align:center;">One stop solution to Hostel/PG Finding Queries</h1>


                        <div class="hero__searchbar homeSearchbar" style="font-size:16px">
                         
                            <form id="js-search-form" method="GET" action="<?php echo base_url(); ?>home/search">
                                <div class="col-md-3">
                                    <input type="text" class="form-control search_box" name="location" placeholder="Select City, Locality, Landmark or Pincode" id="searchbox"/>
                                    <div class="search_dropdown">
                                        <div class="search_content">

                                        </div>
                                        <div class="search_close">Close</div>
                                    </div>
                                </div>
                                <script type="text/javascript">
                                    function change_range()
                                    {
                                        document.getElementById("range_max").innerText = document.getElementById("range_control").value + "/m";
                                    }
                                </script>
                                <div class="col-md-2">
                                    <input type="range" id="range_control" onchange="change_range()" name="price_range" calss="form-control" min="0" max="50000"/>
                                    <label  style="color:white;display:inline;margin-bottom:0px;">Price : </label>
                                    <!--                                                <label id="range_min" style="color:white;display:inline">4</label>-->
                                    <label id="range_max" style="color:white;float:right;display:inline;margin-bottom:0px;">25000/m</label>
                                </div>

                                <div class="col-md-2" style="color:white;">
                                    <input type="radio" name="gender" checked="" value="male" id="male" > <label for="male" style="display:inline;"> Male </label>
                                    <input type="radio" name="gender" value="female" id="female"> <label for="female" style="display:inline"> Female </label>
                                </div>
                                <div class="col-md-3" style="color:white;">
                                    <input type="radio" name="property_type" checked="" value="hostel" id="hostel" > <label for="hostel" style="display:inline;">Hostel </label>&nbsp;&nbsp;&nbsp;
                                    <input type="radio" name="property_type" value="pg" id="pg"> <label for="pg" style="display:inline">P.G. </label>&nbsp;&nbsp;&nbsp;
                                    <input type="radio" name="property_type" value="room" id="room"> <label for="room" style="display:inline">Room </label>
                                </div>
                                <div class="col-md-2">
                                    <input type="submit" value="Search" class="btn btn-primary" style="width:100%"/>
                                </div>
                            </form>
                               <script src="<?php echo base_url(); ?>includes/js/jquery-1.10.2.min.js"></script>                            
                            <script type="text/javascript">
                                $(document).ready(function() {
                                    $(".search_close").click(function() {
                                        $(".search_dropdown").slideUp();
                                    });
                                    $(".search_box").keyup(function() {
                                        $(".search_dropdown").slideDown();
                                        $.ajax({
                                            type: "get",
                                            url: base_url+"home/get_search",
                                            data: 'search=' + $(this).val(),
                                         //   dataType: "json",
                                            success: function(result)
                                            {
                                                $(".search_content").html(result);
                                            }
                                        });
                                    });    
                                });    
                                function hello(el)
                                {
                                    $(".search_box").val($(el).attr("rel"));
                                    $(".search_dropdown").slideUp();
                                }
                            </script>
                        </div>
                    </div>
                    <br clear="all"/><br clear="all"/><br clear="all"/>
                    <div class="col-md-12">
                        <h4 class="city__amenities__heading">Basic Facilities in Hostel Network</h4>
                    </div>
                    <div class="col-md-12">
                        <div class="city__amenities__block">
                            <div class="hero__amenities__wrapper">
                                <span class="hero__amenities__element hero__amenities__bed"></span>
                                <span class="hero__amenities__element--text ">Bed</span>
                            </div>
                            <div class="hero__amenities__wrapper">
                                <span class="hero__amenities__element hero__amenities__locker"></span>
                                <span class="hero__amenities__element--text ">Locker</span>
                            </div>
                            <div class="hero__amenities__wrapper">
                                <span class="hero__amenities__element hero__amenities_washrooms"></span>
                                <span class="hero__amenities__element--text ">Clean Washrooms</span>
                            </div>
                            <div class="hero__amenities__wrapper">
                                <span class="hero__amenities__element hero__amenities__24_hour"></span>
                                <span class="hero__amenities__element--text ">24 Hour Water & Electricity</span>
                            </div>
                            <div class="hero__amenities__wrapper">
                                <span class="hero__amenities__element hero__amenities__security"></span>
                                <span class="hero__amenities__element--text ">Security</span>
                            </div>
                            <div class="hero__amenities__wrapper">
                                <span class="hero__amenities__element hero__amenities__parking"></span>
                                <span class="hero__amenities__element--text ">Parking</span>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- END TOP AREA  -->

<div class="gap"></div>


<div class="container">
    <div class="row row-wrap" data-gutter="60">

        <div class="col-md-4">
            <div class="thumb">

                <div class="thumb-caption">
                    <h5 class="thumb-title" style="text-align:center;font-size:30px;"><a class="text-darken" href="index.html#">How we work?</a></h5>
                    <hr/>
                    <p class="thumb-desc" style='font-size:15px;'>Hostelnetwork.in advertise and promote your hostel/PG through social media platforms. We help you to expand your hostel/PG brand and boost your business.</p>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="thumb">

                <div class="thumb-caption">
                    <h5 class="thumb-title" style="text-align:center;font-size:30px;"><a class="text-darken" href="index.html#">Who we are?</a></h5>
                    <hr/>
                    <p class="thumb-desc" style='font-size:15px;'>Hostelnetwork.in provides you complete information about hostels and PGs around you like facilities, food menu, address, pictures, house rules, reviews and ratings without going to each hostels/PGs and check them personally.</p>

                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="thumb">

                <div class="thumb-caption">
                    <h5 class="thumb-title" style="text-align:center;font-size:30px;"><a class="text-darken" href="index.html#">Why choose us?</a></h5>
                    <hr/>
                    <p class="thumb-desc">
                    <ul class="thumb-desc" style='font-size:15px;'>
                        <li> Dedicated website for hostels/PGs</li>
                        <li>Largest network of students</li>
                        <li>User friendly search</li>
                        <li>Social media marketing</li>
                        <li>Covering all india major cities</li>
                    </ul></p>
                </div>
            </div>
        </div>
    </div>
    <div class="gap gap-small"></div>
</div>
<div class="bg-holder">
    <div class="bg-mask"></div>
    <div class="bg-parallax" style="background-image:url(<?php echo base_url(); ?>includes/img/DSC00994.jpg);"></div>
    <div class="bg-content">
        <div class="container">
            <div class="gap gap-big text-center text-white">
                <!--                            <h2 class="text-uc mb20">Last Minute Deal</h2>
                                            <ul class="icon-list list-inline-block mb0 last-minute-rating">
                                                <li><i class="fa fa-star"></i>
                                                </li>
                                                <li><i class="fa fa-star"></i>
                                                </li>
                                                <li><i class="fa fa-star"></i>
                                                </li>
                                                <li><i class="fa fa-star"></i>
                                                </li>
                                                <li><i class="fa fa-star"></i>
                                                </li>
                                            </ul>-->
                <h5 class="last-minute-title"><a href="<?php echo base_url(); ?>home/signup">Register Now</a></h5>
                <!--                            <p class="last-minute-date">Fri 14 Mar - Sun 16 Mar</p>
                                            <p class="mb20"><b>$120</b> / person</p><a class="btn btn-lg btn-white btn-ghost" href="index.html#">Book Now <i class="fa fa-angle-right"></i></a>-->
            </div>
        </div>
    </div>
</div>
<div class="container">
    <div class="gap"></div>
    <h2 class="text-center">Recently Submitted Hostels/PGs</h2>
    <hr/>
    <div class="gap">
        <style>
            body{width:610;}
            .demo-table
            {
                float:left;
            }
            .demo-table th {background: #32C2DB;padding: 5px;text-align: left;color:#FFF;}

            .demo-table td div.feed_title{text-decoration: none;color:#00d4ff;font-weight:bold;}
            .demo-table ul{float:left;list-style-type:none;padding:0px;}
            .demo-table li{cursor:pointer;list-style-type:none;display: inline-block;color: #F0F0F0;text-shadow: 0 0 1px #666666;font-size:20px;}
            .demo-table .highlight, .demo-table .selected {color:#F4B30A;text-shadow: 0 0 1px #F48F0A;}
        </style>

        <?php
        if (count($hostels) > 0) {
            foreach ($hostels as $hostel) {
                ?>
                <a href="<?php echo base_url(); ?>home/more_detail?id=<?php echo $hostel["id"] ?>" >
                    <div class="col-md-3" style="height:200px;width:270px;margin-right:10px;" >

                        <img src="<?php echo base_url() ?>includes/upload/thimg/<?php echo $hostel["img"] ?>" style="z-index:1;position:absolute;border-radius:10px;min-height:200px;height:200px; filter: brightness(60%);filter: -moz-brightness(60%);filter: -webkit-brightness(60%);filter: -o-brightness(60%);" class="img-thumbnail"/>

                        <div style="position:absolute;top:10px;color:white;">helo</div>
                        <center>
                            <br clear="all"/>
                            <table class="" width="95%" style="z-index:5;position:absolute;color:white;margin-left:10px;font-size:17px;text-transform:capitalize;" >
                                <tr>
                                    <td >
                                        <?php
                                        if ($hostel["property_for"] == "male") {
                                            ?>
                                            <i class="fa fa-male"></i>
                                            <?php
                                        } else {
                                            ?>
                                            <i class="fa fa-female"></i>
                                            <?php
                                        }
                                        ?>
                                        <?php echo substr($hostel["property_for"], 0, 1); ?></td>
                                    <td align="right" width="48%"><span style="border:1px white solid;padding:4px;border-radius:2px;"><?php echo $hostel["property_type"]; ?></span></td>
                                </tr>
                                <tr height="90px">
                                    <td colspan="2"></td>
                                </tr>
                                <tr>
                                    <td ><?php echo $hostel["occupancy"] ?></td> <td>₹ <?php
                                    if($hostel["occupancy"] != "sharing")
                                    {
                                    echo $hostel["room_rent"]; 
                                    }
                                    else
                                    {
                                        $rent_ex = explode("#", $hostel["room_rent1"]);
                                        echo $rent_ex[0];
                                    }
                                            ?>/<span style="text-transform:lowercase;">m</span></td>
                                </tr>
                                <tr>
                                    <td> View : <?php echo $hostel["views"] ?></td>
                                    <td>
                                        <table class="demo-table" align="center">
                                            <td>
                                                <ul>
                                                    <?php
                                                    for ($i = 1; $i <= 5; $i++) {
                                                        if ($i <= $hostel["total_rating"]) {
                                                            ?>
                                                            <li class="selected">&#9733;</li>
                                                            <?php
                                                        } else {
                                                            ?>
                                                            <li>&#9733;</li>
                                                                <?php
                                                            }
                                                        }
                                                        ?>


                                                </ul>
                                            </td>
                                        </table>
                                    </td>
                                </tr>
                            </table>                            
                        </center>
                    </div>
                </a>   
        <?php
    }
} else {
    echo "<h3>No Record Found</h3>";
}
?>


    </div>
</div>


