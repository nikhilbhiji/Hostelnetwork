<ul>
    <li><a href="<?php echo base_url() ?>head/add_city">Add City</a></li>
    <li><a href="<?php echo base_url() ?>head/manage_city">Manage City</a></li>
</ul>