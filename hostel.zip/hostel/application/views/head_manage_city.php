

<br clear="all"/>

<div class="container">
    <div class="row " >   
        <div class="col-md-3">
            <?php include("head_nav.php");?>
        </div>
        <div class="col-md-6">
            <h4>Maange City</h4>
            <hr/>
            <form action="<?php echo base_url();?>head/add_city_action" method="post">                      
            <table class="table table-bordered table-hover">             
                <tr>
                    <th>#</th>
                    <th>Name</th>
                  
                    <th>Action</th>
                </tr>
                <?php
                $i=1;
                foreach($cities as $city)
                {
                 ?>
                <tr>
                    <td><?php echo $i;?></td>
                    <td><?php echo $city["city_name"];?></td>
                   
                    <td><a href="<?php echo base_url()?>head/delete_city?cid=<?php echo $city["id"]?>" class="btn btn-danger">Delete</a></td>
                </tr>
                <?php
                $i++;
                }                
                ?>
            </table>
            </form>
        </div>

    </div>
    <div class="gap gap-small"></div>
</div>




