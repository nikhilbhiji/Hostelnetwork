<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Home extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->helper('url');
        $this->load->library('session');
        $this->load->library("pagination");
        $this->load->library('image_lib');
        $this->load->library('form_validation');
        $this->load->library('email');
        $this->load->library('cart');
        $this->load->helper(array('email', 'form', 'file'));
        $this->load->model('common_db');
        ini_set('memory_limit', "256M");
    }

    public function index() {
        $this->load->view('header');
        $this->data["hostels"] = $this->common_db->get_recent_hostels();
        $this->load->view('index', $this->data);
        $this->load->view('footer');
    }

    public function search() {
        $this->load->view('header');

        $price_range = $this->input->get("price_range");
        $gender = $this->input->get("gender");
        $location = $this->input->get("location");
        $property_type = $this->input->get("property_type");
        $occupancy = $this->input->get("occupancy");
        $food_type = $this->input->get("food_type");
        $occupancy = $this->input->get("occupancy");
        if ($price_range != "") {
            $this->data["hostels"] = $this->common_db->search_hostels($price_range, $gender, $location, $property_type, $food_type, $occupancy);
        } else {
            $this->data["hostels"] = $this->common_db->search_hostels1($location);
        }

        $this->load->view('search', $this->data);
        $this->load->view('footer');
    }

    public function more_detail() {
        $this->load->view('header');
        $id = $this->input->get("id");

        $views = $this->common_db->get_hostel_view($id);

        $new_view = $views["views"] + 1;
        $this->common_db->update_views($new_view, $id);
        $this->data["hostel"] = $this->common_db->get_single_hostel($id);
        $this->data["reviews"] = $this->common_db->get_reviews($id);
        $this->load->view('more_detail', $this->data);
        $this->load->view('footer');
    }

    public function login() {
        $this->load->view('header');
        $this->load->view('login');
        $this->load->view('footer');
    }

    public function login_action() {
        $email = $this->input->post("email");
        $password = $this->input->post("password");
        $query = $this->common_db->login_user($email, $password);
        $result = $query->row_array();
        if ($query->num_rows() > 0) {
            $this->session->set_userdata("user", $result["owner_name"]);
            $this->session->set_userdata("user_id", $result["id"]);
            redirect("home/profile");
        } else {
            $this->session->set_flashdata('notify', "Please enter correct email and password.");
            redirect("home/login");
        }
    }

    public function logout() {
        $this->session->set_userdata("user", "");
        $this->session->set_userdata("user_id", "");
        redirect("home");
    }

    function check_auth() {
        if ($this->session->userdata("user") == "") {
            redirect("home");
        }
    }

    public function profile() {
        $this->check_auth();
        $uid = $this->session->userdata("user_id");
        $this->load->view('header');
        $this->data["cities"] = $this->common_db->get_cities();
        $this->data["hostel"] = $this->common_db->get_profile_detail($uid);
        $this->load->view('profile', $this->data);
        $this->load->view('footer');
    }

    public function check_booking() {
        $this->check_auth();
        $uid = $this->session->userdata("user_id");
        $this->load->view('header');
        $this->data["bookings"] = $this->common_db->get_bookings($uid);
        $this->load->view('bookings', $this->data);
        $this->load->view('footer');
    }

    public function signup() {
        $this->load->view('header');
        $this->data["cities"] = $this->common_db->get_cities();
        $this->load->view('signup', $this->data);
        $this->load->view('footer');
    }

    public function signup_action() {
        $signup = array();
        $signup["property_for"] = $this->input->post("property_for");
        $signup["property_type"] = $this->input->post("property_type");
        $signup["occupancy"] = $this->input->post("occupancy");
        $signup["property_name"] = $this->input->post("property_name");
        $signup["owner_name"] = $this->input->post("owner_name");
        $signup["mobile_no"] = $this->input->post("mobile_no");
        $signup["alternate_no"] = $this->input->post("alternate_no");
        $signup["house_no"] = $this->input->post("house_no");
        $signup["landmark"] = $this->input->post("landmark");
        $signup["city"] = $this->input->post("city");
        $signup["email"] = $this->input->post("email");
        $signup["password"] = base64_encode($this->input->post("password"));

        $food_type1 = $this->input->post("food_type");
        if (!empty($food_type1)) {
            $signup["food_type"] = implode("#", $this->input->post("food_type"));
        }

        $meals1 = $this->input->post("meals");
        if (!empty($meals1)) {
            $signup["meals"] = implode("#", $this->input->post("meals"));
        }



        if ($signup["occupancy"] != "single") {
            $signup["room_rent1"] = implode("#", $this->input->post("room_rent1"));
            $signup["room_security1"] = implode("#", $this->input->post("room_security1"));
        } else {
            $signup["room_rent"] = $this->input->post("room_rent");
            $signup["room_security"] = $this->input->post("room_security");
        }

        $facilitys = $this->input->post("facilities");
        if (!empty($facilitys)) {
            $signup["facilities"] = implode("#", $this->input->post("facilities"));
        }

        $house_rule1 = $this->input->post("house_rule");
        if (!empty($house_rule1)) {
            $signup["house_rule"] = implode("#", $this->input->post("house_rule"));
        }
        $signup["location"] = $this->input->post("location");
        $signup["lat"] = $this->input->post("lat");
        $signup["long"] = $this->input->post("long");
        $signup["youtube_link"] = $this->input->post("youtube_link");


        $To = $this->input->post("email");
        $From = "info.@hostelnetwork.in"; // sender

        $subject = "Hostel Registration";
        $MessageBody = "<html>
                    <head>
                    <title></title>
                    </head>
                    <body>
                   <p>Thank you for Registration in our website.</p>
                   <p>Name : " . $signup["owner_name"] . "</p>
                   <p>Mobile No : " . $signup["mobile_no"] . "</p>
                   <p>Property Type : " . $signup["property_type"] . "</p>        
                    </body>
                    </html>
                    ";

        $headers = "MIME-Version: 1.0\r\n";
        $headers .= "Content-type: text/html; charset=iso-8859-1\r\n";
        $headers .= "From:$From\r\n";
        mail($To, $subject, $MessageBody, $headers);
        mail("info.@hostelnetwork.in", $subject, $MessageBody, $headers);


        $image = "";
        if (isset($_FILES["img"]["name"])) {
            $imgext = strtolower(pathinfo($_FILES["img"]["name"], PATHINFO_EXTENSION));
            if ($imgext == "jpg" || $imgext == "png" || $imgext == "jpeg" || $imgext == "gif") {
                $rand_name = "upload_" . date("Y-m-dH-i-s") . rand(0000, 9999);
                move_uploaded_file($_FILES["img"]["tmp_name"], "includes/upload/" . $rand_name . "." . $imgext);

                $image = $rand_name . "." . $imgext;
                $add = "includes/upload/" . $rand_name . "." . $imgext; //for thumbnail
                ///////// Start the thumbnail generation//////////////
                $n_width = 800;          // Fix the width of the thumb nail images
                $n_height = 320;         // Fix the height of the thumb nail imaage


                $tsrc = "includes/upload/thimg/" . $rand_name . "." . $imgext;   // Path where thumb nail image will be stored
                ////////////// Starting of GIF thumb nail creation ///////////
                if (@$_FILES['img']['type'] == "image/gif") {
                    $im = ImageCreateFromGIF($add);
                    $width = ImageSx($im);              // Original picture width is stored
                    $height = ImageSy($im);                  // Original picture height is stored
                    $n_height = ($n_width / $width) * $height; // Add this line to maintain aspect ratio
                    $newimage = imagecreatetruecolor($n_width, $n_height);
                    imageCopyResized($newimage, $im, 0, 0, 0, 0, $n_width, $n_height, $width, $height);
                    if (function_exists("imagegif")) {
                        Header("Content-type: image/gif");
                        ImageGIF($newimage, $tsrc);
                    }
                    chmod("$tsrc", 0777);
                }

                ////////////// starting of JPG thumb nail creation //////////
                if ($_FILES['img']['type'] == "image/jpeg") {
                    $im = ImageCreateFromJPEG($add);
                    $width = ImageSx($im);              // Original picture width is stored
                    $height = ImageSy($im);             // Original picture height is stored
                    $n_height = ($n_width / $width) * $height; // Add this line to maintain aspect ratio
                    $newimage = imagecreatetruecolor($n_width, $n_height);
                    imageCopyResized($newimage, $im, 0, 0, 0, 0, $n_width, $n_height, $width, $height);
                    ImageJpeg($newimage, $tsrc);
                    chmod("$tsrc", 0777);
                }

                ////////////// starting of png thumb nail creation //////////
                if ($_FILES['img']['type'] == "image/png") {
                    $im = imagecreatefrompng($add);
                    $width = ImageSx($im);              // Original picture width is stored
                    $height = ImageSy($im);             // Original picture height is stored
                    $n_height = ($n_width / $width) * $height; // Add this line to maintain aspect ratio
                    $newimage = imagecreatetruecolor($n_width, $n_height);
                    imageCopyResized($newimage, $im, 0, 0, 0, 0, $n_width, $n_height, $width, $height);
                    ImageJpeg($newimage, $tsrc);
                    chmod("$tsrc", 0777);
                }
            }
        }




        $image2 = "";
        if (isset($_FILES["img2"]["name"])) {
            $imgext = strtolower(pathinfo($_FILES["img2"]["name"], PATHINFO_EXTENSION));
            if ($imgext == "jpg" || $imgext == "png" || $imgext == "jpeg" || $imgext == "gif") {
                $rand_name = "upload_" . date("Y-m-dH-i-s") . rand(0000, 9999);
                move_uploaded_file($_FILES["img2"]["tmp_name"], "includes/upload/" . $rand_name . "." . $imgext);

                $image2 = $rand_name . "." . $imgext;
                $add = "includes/upload/" . $rand_name . "." . $imgext; //for thumbnail
                ///////// Start the thumbnail generation//////////////
                $n_width = 800;          // Fix the width of the thumb nail images
                $n_height = 320;         // Fix the height of the thumb nail imaage


                $tsrc = "includes/upload/thimg/" . $rand_name . "." . $imgext;   // Path where thumb nail image will be stored
                ////////////// Starting of GIF thumb nail creation ///////////
                if (@$_FILES['img2']['type'] == "image/gif") {
                    $im = ImageCreateFromGIF($add);
                    $width = ImageSx($im);              // Original picture width is stored
                    $height = ImageSy($im);                  // Original picture height is stored
                    $n_height = ($n_width / $width) * $height; // Add this line to maintain aspect ratio
                    $newimage = imagecreatetruecolor($n_width, $n_height);
                    imageCopyResized($newimage, $im, 0, 0, 0, 0, $n_width, $n_height, $width, $height);
                    if (function_exists("imagegif")) {
                        Header("Content-type: image/gif");
                        ImageGIF($newimage, $tsrc);
                    }
                    chmod("$tsrc", 0777);
                }

                ////////////// starting of JPG thumb nail creation //////////
                if ($_FILES['img2']['type'] == "image/jpeg") {
                    $im = ImageCreateFromJPEG($add);
                    $width = ImageSx($im);              // Original picture width is stored
                    $height = ImageSy($im);             // Original picture height is stored
                    $n_height = ($n_width / $width) * $height; // Add this line to maintain aspect ratio
                    $newimage = imagecreatetruecolor($n_width, $n_height);
                    imageCopyResized($newimage, $im, 0, 0, 0, 0, $n_width, $n_height, $width, $height);
                    ImageJpeg($newimage, $tsrc);
                    chmod("$tsrc", 0777);
                }

                ////////////// starting of png thumb nail creation //////////
                if ($_FILES['img2']['type'] == "image/png") {
                    $im = imagecreatefrompng($add);
                    $width = ImageSx($im);              // Original picture width is stored
                    $height = ImageSy($im);             // Original picture height is stored
                    $n_height = ($n_width / $width) * $height; // Add this line to maintain aspect ratio
                    $newimage = imagecreatetruecolor($n_width, $n_height);
                    imageCopyResized($newimage, $im, 0, 0, 0, 0, $n_width, $n_height, $width, $height);
                    ImageJpeg($newimage, $tsrc);
                    chmod("$tsrc", 0777);
                }
            }
        }

        $image3 = "";
        if (isset($_FILES["img3"]["name"])) {
            $imgext = strtolower(pathinfo($_FILES["img3"]["name"], PATHINFO_EXTENSION));
            if ($imgext == "jpg" || $imgext == "png" || $imgext == "jpeg" || $imgext == "gif") {
                $rand_name = "upload_" . date("Y-m-dH-i-s") . rand(0000, 9999);
                move_uploaded_file($_FILES["img3"]["tmp_name"], "includes/upload/" . $rand_name . "." . $imgext);

                $image3 = $rand_name . "." . $imgext;
                $add = "includes/upload/" . $rand_name . "." . $imgext; //for thumbnail
                ///////// Start the thumbnail generation//////////////
                $n_width = 800;          // Fix the width of the thumb nail images
                $n_height = 320;         // Fix the height of the thumb nail imaage


                $tsrc = "includes/upload/thimg/" . $rand_name . "." . $imgext;   // Path where thumb nail image will be stored
                ////////////// Starting of GIF thumb nail creation ///////////
                if (@$_FILES['img3']['type'] == "image/gif") {
                    $im = ImageCreateFromGIF($add);
                    $width = ImageSx($im);              // Original picture width is stored
                    $height = ImageSy($im);                  // Original picture height is stored
                    $n_height = ($n_width / $width) * $height; // Add this line to maintain aspect ratio
                    $newimage = imagecreatetruecolor($n_width, $n_height);
                    imageCopyResized($newimage, $im, 0, 0, 0, 0, $n_width, $n_height, $width, $height);
                    if (function_exists("imagegif")) {
                        Header("Content-type: image/gif");
                        ImageGIF($newimage, $tsrc);
                    }
                    chmod("$tsrc", 0777);
                }

                ////////////// starting of JPG thumb nail creation //////////
                if ($_FILES['img3']['type'] == "image/jpeg") {
                    $im = ImageCreateFromJPEG($add);
                    $width = ImageSx($im);              // Original picture width is stored
                    $height = ImageSy($im);             // Original picture height is stored
                    $n_height = ($n_width / $width) * $height; // Add this line to maintain aspect ratio
                    $newimage = imagecreatetruecolor($n_width, $n_height);
                    imageCopyResized($newimage, $im, 0, 0, 0, 0, $n_width, $n_height, $width, $height);
                    ImageJpeg($newimage, $tsrc);
                    chmod("$tsrc", 0777);
                }

                ////////////// starting of png thumb nail creation //////////
                if ($_FILES['img3']['type'] == "image/png") {
                    $im = imagecreatefrompng($add);
                    $width = ImageSx($im);              // Original picture width is stored
                    $height = ImageSy($im);             // Original picture height is stored
                    $n_height = ($n_width / $width) * $height; // Add this line to maintain aspect ratio
                    $newimage = imagecreatetruecolor($n_width, $n_height);
                    imageCopyResized($newimage, $im, 0, 0, 0, 0, $n_width, $n_height, $width, $height);
                    ImageJpeg($newimage, $tsrc);
                    chmod("$tsrc", 0777);
                }
            }
        }

        $image4 = "";
        if (isset($_FILES["img4"]["name"])) {
            $imgext = strtolower(pathinfo($_FILES["img4"]["name"], PATHINFO_EXTENSION));
            if ($imgext == "jpg" || $imgext == "png" || $imgext == "jpeg" || $imgext == "gif") {
                $rand_name = "upload_" . date("Y-m-dH-i-s") . rand(0000, 9999);
                move_uploaded_file($_FILES["img4"]["tmp_name"], "includes/upload/" . $rand_name . "." . $imgext);

                $image4 = $rand_name . "." . $imgext;
                $add = "includes/upload/" . $rand_name . "." . $imgext; //for thumbnail
                ///////// Start the thumbnail generation//////////////
                $n_width = 800;          // Fix the width of the thumb nail images
                $n_height = 320;         // Fix the height of the thumb nail imaage


                $tsrc = "includes/upload/thimg/" . $rand_name . "." . $imgext;   // Path where thumb nail image will be stored
                ////////////// Starting of GIF thumb nail creation ///////////
                if (@$_FILES['img4']['type'] == "image/gif") {
                    $im = ImageCreateFromGIF($add);
                    $width = ImageSx($im);              // Original picture width is stored
                    $height = ImageSy($im);                  // Original picture height is stored
                    $n_height = ($n_width / $width) * $height; // Add this line to maintain aspect ratio
                    $newimage = imagecreatetruecolor($n_width, $n_height);
                    imageCopyResized($newimage, $im, 0, 0, 0, 0, $n_width, $n_height, $width, $height);
                    if (function_exists("imagegif")) {
                        Header("Content-type: image/gif");
                        ImageGIF($newimage, $tsrc);
                    }
                    chmod("$tsrc", 0777);
                }

                ////////////// starting of JPG thumb nail creation //////////
                if ($_FILES['img4']['type'] == "image/jpeg") {
                    $im = ImageCreateFromJPEG($add);
                    $width = ImageSx($im);              // Original picture width is stored
                    $height = ImageSy($im);             // Original picture height is stored
                    $n_height = ($n_width / $width) * $height; // Add this line to maintain aspect ratio
                    $newimage = imagecreatetruecolor($n_width, $n_height);
                    imageCopyResized($newimage, $im, 0, 0, 0, 0, $n_width, $n_height, $width, $height);
                    ImageJpeg($newimage, $tsrc);
                    chmod("$tsrc", 0777);
                }

                ////////////// starting of png thumb nail creation //////////
                if ($_FILES['img4']['type'] == "image/png") {
                    $im = imagecreatefrompng($add);
                    $width = ImageSx($im);              // Original picture width is stored
                    $height = ImageSy($im);             // Original picture height is stored
                    $n_height = ($n_width / $width) * $height; // Add this line to maintain aspect ratio
                    $newimage = imagecreatetruecolor($n_width, $n_height);
                    imageCopyResized($newimage, $im, 0, 0, 0, 0, $n_width, $n_height, $width, $height);
                    ImageJpeg($newimage, $tsrc);
                    chmod("$tsrc", 0777);
                }
            }
        }

        $image5 = "";
        if (isset($_FILES["img5"]["name"])) {
            $imgext = strtolower(pathinfo($_FILES["img5"]["name"], PATHINFO_EXTENSION));
            if ($imgext == "jpg" || $imgext == "png" || $imgext == "jpeg" || $imgext == "gif") {
                $rand_name = "upload_" . date("Y-m-dH-i-s") . rand(0000, 9999);
                move_uploaded_file($_FILES["img5"]["tmp_name"], "includes/upload/" . $rand_name . "." . $imgext);

                $image5 = $rand_name . "." . $imgext;
                $add = "includes/upload/" . $rand_name . "." . $imgext; //for thumbnail
                ///////// Start the thumbnail generation//////////////
                $n_width = 800;          // Fix the width of the thumb nail images
                $n_height = 320;         // Fix the height of the thumb nail imaage


                $tsrc = "includes/upload/thimg/" . $rand_name . "." . $imgext;   // Path where thumb nail image will be stored
                ////////////// Starting of GIF thumb nail creation ///////////
                if (@$_FILES['img5']['type'] == "image/gif") {
                    $im = ImageCreateFromGIF($add);
                    $width = ImageSx($im);              // Original picture width is stored
                    $height = ImageSy($im);                  // Original picture height is stored
                    $n_height = ($n_width / $width) * $height; // Add this line to maintain aspect ratio
                    $newimage = imagecreatetruecolor($n_width, $n_height);
                    imageCopyResized($newimage, $im, 0, 0, 0, 0, $n_width, $n_height, $width, $height);
                    if (function_exists("imagegif")) {
                        Header("Content-type: image/gif");
                        ImageGIF($newimage, $tsrc);
                    }
                    chmod("$tsrc", 0777);
                }

                ////////////// starting of JPG thumb nail creation //////////
                if ($_FILES['img5']['type'] == "image/jpeg") {
                    $im = ImageCreateFromJPEG($add);
                    $width = ImageSx($im);              // Original picture width is stored
                    $height = ImageSy($im);             // Original picture height is stored
                    $n_height = ($n_width / $width) * $height; // Add this line to maintain aspect ratio
                    $newimage = imagecreatetruecolor($n_width, $n_height);
                    imageCopyResized($newimage, $im, 0, 0, 0, 0, $n_width, $n_height, $width, $height);
                    ImageJpeg($newimage, $tsrc);
                    chmod("$tsrc", 0777);
                }

                ////////////// starting of png thumb nail creation //////////
                if ($_FILES['img5']['type'] == "image/png") {
                    $im = imagecreatefrompng($add);
                    $width = ImageSx($im);              // Original picture width is stored
                    $height = ImageSy($im);             // Original picture height is stored
                    $n_height = ($n_width / $width) * $height; // Add this line to maintain aspect ratio
                    $newimage = imagecreatetruecolor($n_width, $n_height);
                    imageCopyResized($newimage, $im, 0, 0, 0, 0, $n_width, $n_height, $width, $height);
                    ImageJpeg($newimage, $tsrc);
                    chmod("$tsrc", 0777);
                }
            }
        }
        $signup["img"] = $image;
        $signup["img2"] = $image2;
        $signup["img3"] = $image3;
        $signup["img4"] = $image4;
        $signup["img5"] = $image5;
        $this->common_db->insert_signup($signup);
        $this->session->set_flashdata('signup', "Registration Successful.");





        redirect("home/login");
    }

    public function profile_action() {
        $signup = array();
        $signup["property_for"] = $this->input->post("property_for");
        $signup["property_type"] = $this->input->post("property_type");
        $signup["occupancy"] = $this->input->post("occupancy");
        $signup["property_name"] = $this->input->post("property_name");
        $signup["owner_name"] = $this->input->post("owner_name");
        $signup["mobile_no"] = $this->input->post("mobile_no");
        $signup["alternate_no"] = $this->input->post("alternate_no");
        $signup["house_no"] = $this->input->post("house_no");
        $signup["landmark"] = $this->input->post("landmark");
        $signup["city"] = $this->input->post("city");
        $signup["email"] = $this->input->post("email");
        $signup["password"] = base64_encode($this->input->post("password"));
        $signup["food_type"] = implode("#", $this->input->post("food_type"));
        $signup["meals"] = implode("#", $this->input->post("meals"));


        if ($signup["occupancy"] != "single") {
            $signup["room_rent1"] = implode("#", $this->input->post("room_rent1"));
            $signup["room_security1"] = implode("#", $this->input->post("room_security1"));
        } else {
            $signup["room_rent1"] = "";
            $signup["room_security1"] = "";
            $signup["room_rent"] = $this->input->post("room_rent");
            $signup["room_security"] = $this->input->post("room_security");
        }
        $signup["facilities"] = implode("#", $this->input->post("facilities"));
        $signup["house_rule"] = implode("#", $this->input->post("house_rule"));
        $signup["location"] = $this->input->post("location");
        $signup["lat"] = $this->input->post("lat");
        $signup["long"] = $this->input->post("long");
        $signup["youtube_link"] = $this->input->post("youtube_link");
        $image = "";
        if (empty($_FILES["img"]["name"])) {
            $image = $this->input->post("cur_img");
        } else {

            $imgext = strtolower(pathinfo($_FILES["img"]["name"], PATHINFO_EXTENSION));
            if ($imgext == "jpg" || $imgext == "png" || $imgext == "jpeg" || $imgext == "gif") {
                $rand_name = "upload_" . date("Y-m-dH-i-s") . rand(0000, 9999);
                move_uploaded_file($_FILES["img"]["tmp_name"], "includes/upload/" . $rand_name . "." . $imgext);

                $image = $rand_name . "." . $imgext;
                $add = "includes/upload/" . $rand_name . "." . $imgext; //for thumbnail
                ///////// Start the thumbnail generation//////////////
                $n_width = 800;          // Fix the width of the thumb nail images
                $n_height = 320;         // Fix the height of the thumb nail imaage


                $tsrc = "includes/upload/thimg/" . $rand_name . "." . $imgext;   // Path where thumb nail image will be stored
                ////////////// Starting of GIF thumb nail creation ///////////
                if (@$_FILES['img']['type'] == "image/gif") {
                    $im = ImageCreateFromGIF($add);
                    $width = ImageSx($im);              // Original picture width is stored
                    $height = ImageSy($im);                  // Original picture height is stored
                    $n_height = ($n_width / $width) * $height; // Add this line to maintain aspect ratio
                    $newimage = imagecreatetruecolor($n_width, $n_height);
                    imageCopyResized($newimage, $im, 0, 0, 0, 0, $n_width, $n_height, $width, $height);
                    if (function_exists("imagegif")) {
                        Header("Content-type: image/gif");
                        ImageGIF($newimage, $tsrc);
                    }
                    chmod("$tsrc", 0777);
                }

                ////////////// starting of JPG thumb nail creation //////////
                if ($_FILES['img']['type'] == "image/jpeg") {
                    $im = ImageCreateFromJPEG($add);
                    $width = ImageSx($im);              // Original picture width is stored
                    $height = ImageSy($im);             // Original picture height is stored
                    $n_height = ($n_width / $width) * $height; // Add this line to maintain aspect ratio
                    $newimage = imagecreatetruecolor($n_width, $n_height);
                    imageCopyResized($newimage, $im, 0, 0, 0, 0, $n_width, $n_height, $width, $height);
                    ImageJpeg($newimage, $tsrc);
                    chmod("$tsrc", 0777);
                }

                ////////////// starting of png thumb nail creation //////////
                if ($_FILES['img']['type'] == "image/png") {
                    $im = imagecreatefrompng($add);
                    $width = ImageSx($im);              // Original picture width is stored
                    $height = ImageSy($im);             // Original picture height is stored
                    $n_height = ($n_width / $width) * $height; // Add this line to maintain aspect ratio
                    $newimage = imagecreatetruecolor($n_width, $n_height);
                    imageCopyResized($newimage, $im, 0, 0, 0, 0, $n_width, $n_height, $width, $height);
                    ImageJpeg($newimage, $tsrc);
                    chmod("$tsrc", 0777);
                }
            }
        }

        $image2 = "";
        if (empty($_FILES["img2"]["name"])) {
            $image2 = $this->input->post("cur_img2");
        } else {

            $imgext = strtolower(pathinfo($_FILES["img2"]["name"], PATHINFO_EXTENSION));
            if ($imgext == "jpg" || $imgext == "png" || $imgext == "jpeg" || $imgext == "gif") {
                $rand_name = "upload_" . date("Y-m-dH-i-s") . rand(0000, 9999);
                move_uploaded_file($_FILES["img2"]["tmp_name"], "includes/upload/" . $rand_name . "." . $imgext);

                $image2 = $rand_name . "." . $imgext;
                $add = "includes/upload/" . $rand_name . "." . $imgext; //for thumbnail
                ///////// Start the thumbnail generation//////////////
                $n_width = 800;          // Fix the width of the thumb nail images
                $n_height = 320;         // Fix the height of the thumb nail imaage


                $tsrc = "includes/upload/thimg/" . $rand_name . "." . $imgext;   // Path where thumb nail image will be stored
                ////////////// Starting of GIF thumb nail creation ///////////
                if (@$_FILES['img2']['type'] == "image/gif") {
                    $im = ImageCreateFromGIF($add);
                    $width = ImageSx($im);              // Original picture width is stored
                    $height = ImageSy($im);                  // Original picture height is stored
                    $n_height = ($n_width / $width) * $height; // Add this line to maintain aspect ratio
                    $newimage = imagecreatetruecolor($n_width, $n_height);
                    imageCopyResized($newimage, $im, 0, 0, 0, 0, $n_width, $n_height, $width, $height);
                    if (function_exists("imagegif")) {
                        Header("Content-type: image/gif");
                        ImageGIF($newimage, $tsrc);
                    }
                    chmod("$tsrc", 0777);
                }

                ////////////// starting of JPG thumb nail creation //////////
                if ($_FILES['img2']['type'] == "image/jpeg") {
                    $im = ImageCreateFromJPEG($add);
                    $width = ImageSx($im);              // Original picture width is stored
                    $height = ImageSy($im);             // Original picture height is stored
                    $n_height = ($n_width / $width) * $height; // Add this line to maintain aspect ratio
                    $newimage = imagecreatetruecolor($n_width, $n_height);
                    imageCopyResized($newimage, $im, 0, 0, 0, 0, $n_width, $n_height, $width, $height);
                    ImageJpeg($newimage, $tsrc);
                    chmod("$tsrc", 0777);
                }

                ////////////// starting of png thumb nail creation //////////
                if ($_FILES['img2']['type'] == "image/png") {
                    $im = imagecreatefrompng($add);
                    $width = ImageSx($im);              // Original picture width is stored
                    $height = ImageSy($im);             // Original picture height is stored
                    $n_height = ($n_width / $width) * $height; // Add this line to maintain aspect ratio
                    $newimage = imagecreatetruecolor($n_width, $n_height);
                    imageCopyResized($newimage, $im, 0, 0, 0, 0, $n_width, $n_height, $width, $height);
                    ImageJpeg($newimage, $tsrc);
                    chmod("$tsrc", 0777);
                }
            }
        }

        $image3 = "";
        if (empty($_FILES["img3"]["name"])) {
            $image3 = $this->input->post("cur_img3");
        } else {

            $imgext = strtolower(pathinfo($_FILES["img3"]["name"], PATHINFO_EXTENSION));
            if ($imgext == "jpg" || $imgext == "png" || $imgext == "jpeg" || $imgext == "gif") {
                $rand_name = "upload_" . date("Y-m-dH-i-s") . rand(0000, 9999);
                move_uploaded_file($_FILES["img3"]["tmp_name"], "includes/upload/" . $rand_name . "." . $imgext);

                $image3 = $rand_name . "." . $imgext;
                $add = "includes/upload/" . $rand_name . "." . $imgext; //for thumbnail
                ///////// Start the thumbnail generation//////////////
                $n_width = 800;          // Fix the width of the thumb nail images
                $n_height = 320;         // Fix the height of the thumb nail imaage


                $tsrc = "includes/upload/thimg/" . $rand_name . "." . $imgext;   // Path where thumb nail image will be stored
                ////////////// Starting of GIF thumb nail creation ///////////
                if (@$_FILES['img3']['type'] == "image/gif") {
                    $im = ImageCreateFromGIF($add);
                    $width = ImageSx($im);              // Original picture width is stored
                    $height = ImageSy($im);                  // Original picture height is stored
                    $n_height = ($n_width / $width) * $height; // Add this line to maintain aspect ratio
                    $newimage = imagecreatetruecolor($n_width, $n_height);
                    imageCopyResized($newimage, $im, 0, 0, 0, 0, $n_width, $n_height, $width, $height);
                    if (function_exists("imagegif")) {
                        Header("Content-type: image/gif");
                        ImageGIF($newimage, $tsrc);
                    }
                    chmod("$tsrc", 0777);
                }

                ////////////// starting of JPG thumb nail creation //////////
                if ($_FILES['img3']['type'] == "image/jpeg") {
                    $im = ImageCreateFromJPEG($add);
                    $width = ImageSx($im);              // Original picture width is stored
                    $height = ImageSy($im);             // Original picture height is stored
                    $n_height = ($n_width / $width) * $height; // Add this line to maintain aspect ratio
                    $newimage = imagecreatetruecolor($n_width, $n_height);
                    imageCopyResized($newimage, $im, 0, 0, 0, 0, $n_width, $n_height, $width, $height);
                    ImageJpeg($newimage, $tsrc);
                    chmod("$tsrc", 0777);
                }

                ////////////// starting of png thumb nail creation //////////
                if ($_FILES['img3']['type'] == "image/png") {
                    $im = imagecreatefrompng($add);
                    $width = ImageSx($im);              // Original picture width is stored
                    $height = ImageSy($im);             // Original picture height is stored
                    $n_height = ($n_width / $width) * $height; // Add this line to maintain aspect ratio
                    $newimage = imagecreatetruecolor($n_width, $n_height);
                    imageCopyResized($newimage, $im, 0, 0, 0, 0, $n_width, $n_height, $width, $height);
                    ImageJpeg($newimage, $tsrc);
                    chmod("$tsrc", 0777);
                }
            }
        }

        $image4 = "";
        if (empty($_FILES["img4"]["name"])) {
            $image4 = $this->input->post("cur_img4");
        } else {

            $imgext = strtolower(pathinfo($_FILES["img4"]["name"], PATHINFO_EXTENSION));
            if ($imgext == "jpg" || $imgext == "png" || $imgext == "jpeg" || $imgext == "gif") {
                $rand_name = "upload_" . date("Y-m-dH-i-s") . rand(0000, 9999);
                move_uploaded_file($_FILES["img4"]["tmp_name"], "includes/upload/" . $rand_name . "." . $imgext);

                $image4 = $rand_name . "." . $imgext;
                $add = "includes/upload/" . $rand_name . "." . $imgext; //for thumbnail
                ///////// Start the thumbnail generation//////////////
                $n_width = 800;          // Fix the width of the thumb nail images
                $n_height = 320;         // Fix the height of the thumb nail imaage


                $tsrc = "includes/upload/thimg/" . $rand_name . "." . $imgext;   // Path where thumb nail image will be stored
                ////////////// Starting of GIF thumb nail creation ///////////
                if (@$_FILES['img4']['type'] == "image/gif") {
                    $im = ImageCreateFromGIF($add);
                    $width = ImageSx($im);              // Original picture width is stored
                    $height = ImageSy($im);                  // Original picture height is stored
                    $n_height = ($n_width / $width) * $height; // Add this line to maintain aspect ratio
                    $newimage = imagecreatetruecolor($n_width, $n_height);
                    imageCopyResized($newimage, $im, 0, 0, 0, 0, $n_width, $n_height, $width, $height);
                    if (function_exists("imagegif")) {
                        Header("Content-type: image/gif");
                        ImageGIF($newimage, $tsrc);
                    }
                    chmod("$tsrc", 0777);
                }

                ////////////// starting of JPG thumb nail creation //////////
                if ($_FILES['img4']['type'] == "image/jpeg") {
                    $im = ImageCreateFromJPEG($add);
                    $width = ImageSx($im);              // Original picture width is stored
                    $height = ImageSy($im);             // Original picture height is stored
                    $n_height = ($n_width / $width) * $height; // Add this line to maintain aspect ratio
                    $newimage = imagecreatetruecolor($n_width, $n_height);
                    imageCopyResized($newimage, $im, 0, 0, 0, 0, $n_width, $n_height, $width, $height);
                    ImageJpeg($newimage, $tsrc);
                    chmod("$tsrc", 0777);
                }

                ////////////// starting of png thumb nail creation //////////
                if ($_FILES['img4']['type'] == "image/png") {
                    $im = imagecreatefrompng($add);
                    $width = ImageSx($im);              // Original picture width is stored
                    $height = ImageSy($im);             // Original picture height is stored
                    $n_height = ($n_width / $width) * $height; // Add this line to maintain aspect ratio
                    $newimage = imagecreatetruecolor($n_width, $n_height);
                    imageCopyResized($newimage, $im, 0, 0, 0, 0, $n_width, $n_height, $width, $height);
                    ImageJpeg($newimage, $tsrc);
                    chmod("$tsrc", 0777);
                }
            }
        }

        $image5 = "";
        if (empty($_FILES["img5"]["name"])) {
            $image5 = $this->input->post("cur_img5");
        } else {

            $imgext = strtolower(pathinfo($_FILES["img5"]["name"], PATHINFO_EXTENSION));
            if ($imgext == "jpg" || $imgext == "png" || $imgext == "jpeg" || $imgext == "gif") {
                $rand_name = "upload_" . date("Y-m-dH-i-s") . rand(0000, 9999);
                move_uploaded_file($_FILES["img5"]["tmp_name"], "includes/upload/" . $rand_name . "." . $imgext);

                $image5 = $rand_name . "." . $imgext;
                $add = "includes/upload/" . $rand_name . "." . $imgext; //for thumbnail
                ///////// Start the thumbnail generation//////////////
                $n_width = 800;          // Fix the width of the thumb nail images
                $n_height = 320;         // Fix the height of the thumb nail imaage


                $tsrc = "includes/upload/thimg/" . $rand_name . "." . $imgext;   // Path where thumb nail image will be stored
                ////////////// Starting of GIF thumb nail creation ///////////
                if (@$_FILES['img5']['type'] == "image/gif") {
                    $im = ImageCreateFromGIF($add);
                    $width = ImageSx($im);              // Original picture width is stored
                    $height = ImageSy($im);                  // Original picture height is stored
                    $n_height = ($n_width / $width) * $height; // Add this line to maintain aspect ratio
                    $newimage = imagecreatetruecolor($n_width, $n_height);
                    imageCopyResized($newimage, $im, 0, 0, 0, 0, $n_width, $n_height, $width, $height);
                    if (function_exists("imagegif")) {
                        Header("Content-type: image/gif");
                        ImageGIF($newimage, $tsrc);
                    }
                    chmod("$tsrc", 0777);
                }

                ////////////// starting of JPG thumb nail creation //////////
                if ($_FILES['img5']['type'] == "image/jpeg") {
                    $im = ImageCreateFromJPEG($add);
                    $width = ImageSx($im);              // Original picture width is stored
                    $height = ImageSy($im);             // Original picture height is stored
                    $n_height = ($n_width / $width) * $height; // Add this line to maintain aspect ratio
                    $newimage = imagecreatetruecolor($n_width, $n_height);
                    imageCopyResized($newimage, $im, 0, 0, 0, 0, $n_width, $n_height, $width, $height);
                    ImageJpeg($newimage, $tsrc);
                    chmod("$tsrc", 0777);
                }

                ////////////// starting of png thumb nail creation //////////
                if ($_FILES['img5']['type'] == "image/png") {
                    $im = imagecreatefrompng($add);
                    $width = ImageSx($im);              // Original picture width is stored
                    $height = ImageSy($im);             // Original picture height is stored
                    $n_height = ($n_width / $width) * $height; // Add this line to maintain aspect ratio
                    $newimage = imagecreatetruecolor($n_width, $n_height);
                    imageCopyResized($newimage, $im, 0, 0, 0, 0, $n_width, $n_height, $width, $height);
                    ImageJpeg($newimage, $tsrc);
                    chmod("$tsrc", 0777);
                }
            }
        }
        $signup["img"] = $image;
        $signup["img2"] = $image2;
        $signup["img3"] = $image3;
        $signup["img4"] = $image4;
        $signup["img5"] = $image5;
        $this->common_db->update_profile($signup, $this->session->userdata("user_id"));
        $this->session->set_flashdata('profile', "Profile Updated.");
        redirect("home/profile");
    }

    public function book_now() {
        $this->load->view('header');
        $this->load->view('book_now');
        $this->load->view('footer');
    }

    public function booking_action() {
        $booking = array();
        $booking["name"] = $this->input->post("name");
        $booking["mobile_no"] = $this->input->post("mobile_no");
        $booking["email"] = $this->input->post("email");
        $booking["hostel_id"] = $this->input->post("h_id");
        $this->common_db->insert_booking($booking);
        $this->session->set_flashdata("booking", "Record Inserted");
        redirect("home/book_confirm");
    }

    public function book_confirm() {
        $this->load->view('header');
        $this->load->view('book_confirm');
        $this->load->view('footer');
    }

    public function review_action() {
        $review = array();
        $review["review_title"] = $this->input->post("review_title");
        $review["review_description"] = $this->input->post("review_description");
        $review["rating"] = $this->input->post("rating");
        $review["email"] = $this->input->post("email");
        $review["user_name"] = $this->input->post("user_name");
        $review["contact"] = $this->input->post("contact");
        $review["hostel_id"] = $this->input->post("hostel_id");
        $review["created"] = date("Y-m-d");
        $this->common_db->insert_review($review);
        $this->session->set_flashdata("review", "Record Inserted");


        //   $To = $this->input->post("email");
        $From = $review["email"];
//            $From = "info.@hostelnetwork.in"; // sender
        $subject = "Review";
        $MessageBody = "<html>
                    <head>
                    <title></title>
                    </head>
                    <body>
                    <p>Name : " . $review["user_name"] . "</p>
                   <p>Email : " . $review["email"] . "</p>
                     <p>Contact No : " . $review["contact"] . "</p>
                    <p>Review Title : " . $review["review_title"] . "</p>
                   <p>Description : " . $review["review_description"] . "</p>
                    </body>
                    </html>
                    ";

        $headers = "MIME-Version: 1.0\r\n";
        $headers .= "Content-type: text/html; charset=iso-8859-1\r\n";
        $headers .= "From:$From\r\n";
        mail("info.@hostelnetwork.in", $subject, $MessageBody, $headers);

        redirect("home/more_detail?id=" . $this->input->post("hostel_id"));
    }

    public function delete_booking() {
        $bid = $this->input->get("id");
        $this->common_db->delete_booking($this->session->set_userdata("user_id"), $bid);
        $this->session->set_flashdata("booking_delete", "Record Deleted");
        redirect("home/check_booking");
    }

    public function feedback_action() {
        $feedback = array();
        $feedback["name"] = $this->input->post("name");
        $feedback["email_id"] = $this->input->post("email");
        $feedback["contact_no"] = $this->input->post("contact");
        $feedback["feedback_category"] = $this->input->post("feedback_category");
        $feedback["message"] = $this->input->post("message");
        $this->common_db->insert_feedback($feedback);
        $this->session->set_flashdata("feedback", "Thank you submitted your feedback.");


        //   $To = $this->input->post("email");
        $From = $feedback["email_id"];
//            $From = "info.@hostelnetwork.in"; // sender
        $subject = "Feedback";
        $MessageBody = "<html>
                    <head>
                    <title></title>
                    </head>
                    <body>
                    <p>Name : " . $feedback["name"] . "</p>
                   <p>Email : " . $feedback["email_id"] . "</p>
                     <p>Contact No : " . $feedback["contact_no"] . "</p>
                    <p>Feedback Category : " . $feedback["feedback_category"] . "</p>
                   <p>Feedback Category : " . $feedback["message"] . "</p>
                    </body>
                    </html>
                    ";

        $headers = "MIME-Version: 1.0\r\n";
        $headers .= "Content-type: text/html; charset=iso-8859-1\r\n";
        $headers .= "From:$From\r\n";
        mail("info.@hostelnetwork.in", $subject, $MessageBody, $headers);


        redirect("home");
    }

    public function all_cities() {
        $this->load->view("header");
        $this->data["cities"] = $this->common_db->get_cities();
        $this->load->view("more_cities", $this->data);
        $this->load->view("footer");
    }

    public function aboutus() {
        $this->load->view("header");
        $this->load->view("aboutus");
        $this->load->view("footer");
    }

    public function get_search() {
        $search = $this->input->get("search");
        $result = $this->common_db->get_hostel_bysearch($search);
        foreach ($result as $hostel) {
            echo "<div style='border-bottom:1px silver solid;padding:10px;cursor:pointer;' class='search_items' onclick='hello(this)' rel='" . $hostel["location"] . "'>" . $hostel["location"] . "</div>";
        }
    }

    public function forget_password() {
        $this->load->view("header");
        $this->load->view("forget_password");
        $this->load->view("footer");
    }

    public function forget_password_action() {
        $email = $this->input->post("email");
        $result = $this->common_db->check_email($email);
        if (count($result) > 0) {

            $To = $this->input->post("email");
            $From = "info.@hostelnetwork.in"; // sender
            $subject = "Forget Password (Hostel Network)";
            $MessageBody = "<html>
                    <head>
                    <title></title>
                    </head>
                    <body>
                   <p>This Email Send by Hostel Network</p>
                    <table>
                    <tr>
                    <td>Your password is : </td>
                    <td>" . base64_decode($result["password"]) . "</td>
                    </tr>
                    </table>
                    </body>
                    </html>
                    ";

            $headers = "MIME-Version: 1.0\r\n";
            $headers .= "Content-type: text/html; charset=iso-8859-1\r\n";
            $headers .= "From:$From\r\n";
            mail($To, $subject, $MessageBody, $headers);
            $this->session->set_flashdata('forget_email', "Password send successfully in your email. Please check your email inbox.");
        } else {
            echo "Please enter correct email id";
            $this->session->set_flashdata('forget_email_wrong', "Please enter correct Email Id.");
        }
        redirect("home/forget_password");
    }

    public function term_condition() {
        $this->load->view("header");
        $this->load->view("term_condition");
        $this->load->view("footer");
    }

    public function privacy_policy() {
        $this->load->view("header");
        $this->load->view("privacy_policy");
        $this->load->view("footer");
    }

}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */
