<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Head extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->helper('url');
        $this->load->library('session');
        $this->load->library("pagination");
        $this->load->library('image_lib');
        $this->load->library('form_validation');
        $this->load->library('email');
        $this->load->library('cart');
        $this->load->helper(array('email', 'form', 'file'));
        $this->load->model("head_db");
    }

    public function index() {
        $this->load->view('header');
        $this->load->view('head');
        $this->load->view('footer');
    }
    public function head_action()
    {
        $head = array();
        $head["uname"] = $this->input->post("username");
        $head["upass"] = base64_encode($this->input->post("username"));
        $result = $this->head_db->head_user($head);
        if(count($result)>0)
        {
          $this->session->set_userdata("head", $result["uname"]);
            $this->session->set_userdata("head_id", $result["id"]);
            redirect("head/head_profile");
        } else {
            $this->session->set_flashdata('notify', "Please enter correct email and password.");
            redirect("head");
        }
        
    }
    public function head_profile()
    {
        $this->load->view('header');
        $this->load->view('head_profile');
        $this->load->view('footer');
    }
   public function add_city()
    {
        $this->load->view('header');
        $this->load->view('head_add_city');
        $this->load->view('footer');
    }
    public function add_city_action()
    {
        $city = array();
        $city["city_name"] = $this->input->post("city_name");
        $this->head_db->insert_city($city);
        $this->add_city();
    }
    public function manage_city()
    {
        $this->load->view('header');
        $this->data["cities"] = $this->head_db->get_cities();
        $this->load->view('head_manage_city',  $this->data);
        $this->load->view('footer');
    }
    public function delete_city()
    {
        $id = $this->input->get("cid");
        $this->head_db->delete_city($id);
        $this->manage_city();
    }
}

?>